import React, { createContext, useContext, useState, useEffect } from "react";

// Create the wishlist context
const WishlistContext = createContext();

// Custom hook to use the wishlist context
export const useWishlist = () => {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error("useWishlist must be used within a WishlistProvider");
  }
  return context;
};

// Wishlist provider component
export const WishlistProvider = ({ children }) => {
  // Initialize wishlist from localStorage if available
  const [wishlist, setWishlist] = useState(() => {
    try {
      const savedWishlist = localStorage.getItem("wishlist");
      return savedWishlist ? JSON.parse(savedWishlist) : [];
    } catch (error) {
      console.error("Error loading wishlist from localStorage:", error);
      return [];
    }
  });
  
  // Save wishlist to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem("wishlist", JSON.stringify(wishlist));
    } catch (error) {
      console.error("Error saving wishlist to localStorage:", error);
    }
  }, [wishlist]);
  
  // Add item to wishlist
  const addToWishlist = (product) => {
    setWishlist(prevWishlist => {
      // Check if the product already exists in the wishlist
      const existingItem = prevWishlist.find(item => item.id === product.id);
      
      if (existingItem) {
        // If it exists, don't add it again
        return prevWishlist;
      } else {
        // If it doesn't exist, add it
        return [...prevWishlist, product];
      }
    });
  };
  
  // Remove item from wishlist
  const removeFromWishlist = (productId) => {
    setWishlist(prevWishlist => 
      prevWishlist.filter(item => item.id !== productId)
    );
  };
  
  // Check if an item is in the wishlist
  const isInWishlist = (productId) => {
    return wishlist.some(item => item.id === productId);
  };
  
  // Clear the entire wishlist
  const clearWishlist = () => {
    setWishlist([]);
  };
  
  // Value to be provided by the context
  const value = {
    wishlist,
    addToWishlist,
    removeFromWishlist,
    isInWishlist,
    clearWishlist
  };
  
  return (
    <WishlistContext.Provider value={value}>
      {children}
    </WishlistContext.Provider>
  );
};

export default WishlistContext;
