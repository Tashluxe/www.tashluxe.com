import React, { createContext, useContext, useState } from "react";
import { getAllProducts } from "../lib/products";

// Create the search context
const SearchContext = createContext();

// Custom hook to use the search context
export const useSearch = () => {
  const context = useContext(SearchContext);
  if (!context) {
    throw new Error("useSearch must be used within a SearchProvider");
  }
  return context;
};

// Search provider component
export const SearchProvider = ({ children }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);

  // Perform search
  const performSearch = (query) => {
    setSearchQuery(query);
    
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }
    
    setIsSearching(true);
    
    // Get all products
    const allProducts = getAllProducts();
    
    // Filter products based on search query
    const results = allProducts.filter(product => {
      const searchTermLower = query.toLowerCase();
      const nameMatch = product.name.toLowerCase().includes(searchTermLower);
      const descriptionMatch = product.description.toLowerCase().includes(searchTermLower);
      const categoryMatch = product.category.toLowerCase().includes(searchTermLower);
      
      return nameMatch || descriptionMatch || categoryMatch;
    });
    
    setSearchResults(results);
    setIsSearching(false);
  };
  
  // Clear search
  const clearSearch = () => {
    setSearchQuery("");
    setSearchResults([]);
  };
  
  // Toggle search modal
  const toggleSearchModal = () => {
    setShowSearchModal(!showSearchModal);
    if (!showSearchModal) {
      // When opening, clear previous results
      clearSearch();
    }
  };
  
  // Close search modal
  const closeSearchModal = () => {
    setShowSearchModal(false);
  };

  // Value to be provided by the context
  const value = {
    searchQuery,
    searchResults,
    isSearching,
    showSearchModal,
    performSearch,
    clearSearch,
    toggleSearchModal,
    closeSearchModal
  };
  
  return (
    <SearchContext.Provider value={value}>
      {children}
    </SearchContext.Provider>
  );
};

export default SearchContext;
