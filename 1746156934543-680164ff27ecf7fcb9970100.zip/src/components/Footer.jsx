import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Facebook, Twitter, Check } from 'lucide-react';

const Footer = () => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [error, setError] = useState('');
  
  const handleEmailChange = (e) => {
    setEmail(e.target.value);
    if (error) setError('');
  };
  
  const handleSubscribe = (e) => {
    e.preventDefault();
    
    // Basic email validation
    if (!email) {
      setError('Please enter your email address');
      return;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('Please enter a valid email address');
      return;
    }
    
    // Simulate API call
    setTimeout(() => {
      setIsSubscribed(true);
      setEmail('');
      
      // Reset after 5 seconds
      setTimeout(() => {
        setIsSubscribed(false);
      }, 5000);
    }, 500);
  };
  
  return (
    <footer className="bg-primary-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        {/* Centered Logo - Now with responsive font size */}
        <div className="text-center mb-12">
          <Link to="/" className="gabriola-font tracking-tight text-white font-bold inline-block" 
            style={{ 
              fontSize: 'clamp(30px, 5vw, 50px)', 
              lineHeight: '1' 
            }}
          >
            T<span className="text-primary-300">ꓥ</span>SHLUXE
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-6 text-primary-200">Customer Service</h3>
            <ul className="space-y-4">
              <li><Link to="/help/contact" className="text-primary-300 hover:text-white text-sm transition-colors">Contact Us</Link></li>
              <li><Link to="/help/shipping" className="text-primary-300 hover:text-white text-sm transition-colors">Shipping & Delivery</Link></li>
              <li><Link to="/help/returns" className="text-primary-300 hover:text-white text-sm transition-colors">Returns & Exchanges</Link></li>
              <li><Link to="/help/payment" className="text-primary-300 hover:text-white text-sm transition-colors">Payment Methods</Link></li>
              <li><Link to="/help/faq" className="text-primary-300 hover:text-white text-sm transition-colors">FAQ</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-6 text-primary-200">Follow Us</h3>
            <ul className="space-y-4">
              <li><a href="https://www.instagram.com/tashluxee?igsh=MWx4NWYxdDMwaWpzdQ%3D%3D&utm_source=qr" target="_blank" rel="noopener noreferrer" className="text-primary-300 hover:text-white text-sm flex items-center transition-colors"><Instagram size={16} className="mr-3" /> Instagram</a></li>
              <li><a href="https://web.facebook.com/" target="_blank" rel="noopener noreferrer" className="text-primary-300 hover:text-white text-sm flex items-center transition-colors"><Facebook size={16} className="mr-3" /> Facebook</a></li>
              <li><a href="https://x.com/" target="_blank" rel="noopener noreferrer" className="text-primary-300 hover:text-white text-sm flex items-center transition-colors"><Twitter size={16} className="mr-3" /> Twitter</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-6 text-primary-200">About TꓥSHLUXE</h3>
            <ul className="space-y-4">
              <li><Link to="/about" className="text-primary-300 hover:text-white text-sm transition-colors">Our Story</Link></li>
              <li><Link to="/stores" className="text-primary-300 hover:text-white text-sm transition-colors">Store Locator</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider mb-6 text-primary-200">Legal</h3>
            <ul className="space-y-4">
              <li><Link to="/privacy" className="text-primary-300 hover:text-white text-sm transition-colors">Privacy Policy</Link></li>
              <li><Link to="/terms" className="text-primary-300 hover:text-white text-sm transition-colors">Terms & Conditions</Link></li>
              <li><Link to="/cookies" className="text-primary-300 hover:text-white text-sm transition-colors">Cookie Policy</Link></li>
              <li><Link to="/accessibility" className="text-primary-300 hover:text-white text-sm transition-colors">Accessibility</Link></li>
            </ul>
          </div>
        </div>
        
        {/* Newsletter - Now with functional signup */}
        <div className="border-t border-primary-700 py-10 mb-8">
          <div className="max-w-md mx-auto text-center">
            <h3 className="text-xl font-medium mb-4">Join Our Newsletter</h3>
            <p className="text-primary-300 mb-6">Subscribe to receive updates, access to exclusive deals, and more.</p>
            
            {isSubscribed ? (
              <div className="bg-ash-dark text-white p-4 rounded-lg flex items-center justify-center">
                <Check size={20} className="mr-2" />
                <span>Thank you for subscribing!</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row">
                <div className="flex-1 mb-3 sm:mb-0">
                  <input
                    type="email"
                    value={email}
                    onChange={handleEmailChange}
                    placeholder="Your email address"
                    className="w-full px-4 py-3 bg-primary-800 border border-primary-700 text-white focus:outline-none focus:ring-2 focus:ring-ash-light rounded-lg sm:rounded-r-none"
                  />
                  {error && <p className="text-primary-300 text-xs mt-1 text-left">{error}</p>}
                </div>
                <button 
                  type="submit" 
                  className="bg-ash-DEFAULT text-white px-6 py-3 uppercase text-sm tracking-wider hover:bg-ash-dark transition-colors rounded-lg sm:rounded-l-none"
                >
                  Subscribe
                </button>
              </form>
            )}
          </div>
        </div>
        
        {/* Copyright */}
        <div className="border-t border-primary-700 pt-8 text-center">
          <p className="text-xs text-primary-400">
            © {new Date().getFullYear()} TꓥSHLUXE. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
