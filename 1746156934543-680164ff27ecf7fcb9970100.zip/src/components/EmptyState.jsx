import React from 'react';
import { ShoppingBag } from 'lucide-react';
import Button from './ui/Button';
import { Link } from 'react-router-dom';

const EmptyState = ({ 
  title = "No products found", 
  message = "Try adjusting your filters or browse our other categories.",
  showResetButton = true,
  onReset,
  showHomeButton = false
}) => {
  return (
    <div className="text-center py-16 bg-primary-50 rounded-lg">
      <div className="inline-flex justify-center items-center w-16 h-16 bg-primary-100 rounded-full mb-4">
        <ShoppingBag size={24} className="text-primary-600" />
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-primary-600 mb-6 max-w-md mx-auto leading-relaxed">{message}</p>
      
      {showResetButton && onReset && (
        <button 
          className="text-accent hover:underline font-medium"
          onClick={onReset}
        >
          Reset Filters
        </button>
      )}
      
      {showHomeButton && (
        <Link to="/">
          <Button variant="primary" className="mt-4">
            Continue Shopping
          </Button>
        </Link>
      )}
    </div>
  );
};

export default EmptyState;
