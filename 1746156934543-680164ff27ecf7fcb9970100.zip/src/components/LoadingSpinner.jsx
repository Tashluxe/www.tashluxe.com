import React from 'react';
import { Loader } from 'lucide-react';

const LoadingSpinner = ({ size = 'medium' }) => {
  const sizeClass = {
    small: 'w-4 h-4',
    medium: 'w-8 h-8',
    large: 'w-12 h-12'
  };

  return (
    <div className="flex justify-center items-center">
      <Loader className={`${sizeClass[size]} animate-spin text-accent`} />
    </div>
  );
};

export default LoadingSpinner;
