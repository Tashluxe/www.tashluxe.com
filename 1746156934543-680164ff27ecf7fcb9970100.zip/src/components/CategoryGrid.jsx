import React from 'react';
import { Link } from 'react-router-dom';

const CategoryGrid = () => {
  const categories = [
    {
      id: 'men',
      name: 'Men',
      image: "https://images.unsplash.com/photo-1617137968427-85924c800a22?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80",
      fallbackImage: "https://images.unsplash.com/photo-1516257984-b1b4d707412e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80",
      description: "Explore our men's collection featuring premium quality clothing and accessories."
    },
    {
      id: 'women',
      name: 'Women',
      image: "https://images.unsplash.com/photo-1618932260643-eee4a2f652a6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=480&q=80",
      fallbackImage: "https://images.unsplash.com/photo-1581044777550-4cfa60707c03?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=386&q=80",
      description: "Discover our women's collection with elegant designs and timeless styles."
    },
    {
      id: 'kids',
      name: 'Kids',
      // Updated primary image for Kids category
      image: "https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1372&q=80",
      fallbackImage: "https://images.unsplash.com/photo-1503919545889-aef636e10ad4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80",
      description: "Shop our kids' collection with comfortable and playful styles for all ages."
    }
  ];

  // Separate the "New Arrivals" category
  const newArrivalsCategory = {
    id: 'new-arrivals',
    name: 'New Arrivals',
    image: "https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    fallbackImage: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    description: "Check out our latest arrivals featuring this season's newest trends and styles."
  };

  // State to handle image loading errors
  const [imageErrors, setImageErrors] = React.useState({
    men: false,
    women: false,
    kids: false,
    'new-arrivals': false
  });

  const handleImageError = (categoryId) => {
    setImageErrors(prev => ({
      ...prev,
      [categoryId]: true
    }));
  };

  return (
    <section className="py-10 sm:py-12 md:py-16 bg-primary-50">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl sm:text-3xl font-bold text-center mb-6 sm:mb-8">Shop by Category</h2>
        
        {/* Main categories (Men, Women, Kids) in a grid that shows all items at once */}
        <div className="grid grid-cols-3 gap-2 sm:gap-4 md:gap-6">
          {categories.map(category => (
            <Link 
              to={`/category/${category.id}`} 
              key={category.id}
              className="group relative overflow-hidden rounded-lg shadow-lg"
            >
              <div className="aspect-[3/4] overflow-hidden">
                <img 
                  src={imageErrors[category.id] ? category.fallbackImage : category.image} 
                  alt={category.name} 
                  className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
                  onError={() => handleImageError(category.id)}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                  <div className="p-2 sm:p-4 md:p-6 w-full">
                    <h3 className="text-sm sm:text-lg md:text-xl font-bold text-white mb-1 sm:mb-2">{category.name}</h3>
                    {/* Description only shows on larger screens */}
                    <p className="hidden sm:block text-white/80 text-xs sm:text-sm mb-2 sm:mb-3 md:mb-4 line-clamp-2">{category.description}</p>
                    <span className="inline-block bg-white text-primary-900 px-2 py-1 sm:px-3 sm:py-1 md:px-4 md:py-2 rounded-full text-xs font-medium hover:bg-ash-dark hover:text-white transition-colors">
                      Shop
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
        
        {/* New Arrivals as a separate full-width section */}
        <div className="mt-6 sm:mt-8">
          <Link 
            to={`/category/${newArrivalsCategory.id}`} 
            className="group relative overflow-hidden rounded-lg shadow-lg block w-full"
          >
            <div className="aspect-[21/9] overflow-hidden">
              <img 
                src={imageErrors['new-arrivals'] ? newArrivalsCategory.fallbackImage : newArrivalsCategory.image} 
                alt={newArrivalsCategory.name} 
                className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
                onError={() => handleImageError('new-arrivals')}
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent flex items-center">
                <div className="p-4 sm:p-6 md:p-10 w-full max-w-md">
                  <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-white mb-1 sm:mb-2 md:mb-3">{newArrivalsCategory.name}</h3>
                  <p className="text-white/80 text-xs sm:text-sm md:text-base mb-2 sm:mb-4 md:mb-6">{newArrivalsCategory.description}</p>
                  <span className="inline-block bg-white text-primary-900 px-3 py-1 sm:px-4 sm:py-2 md:px-6 md:py-3 rounded-full text-xs sm:text-sm font-medium hover:bg-ash-dark hover:text-white transition-colors">
                    Explore Collection
                  </span>
                </div>
              </div>
            </div>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CategoryGrid;
