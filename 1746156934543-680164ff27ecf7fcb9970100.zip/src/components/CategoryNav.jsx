import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const CategoryNav = ({ category, onSubcategoryChange }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const currentPath = location.pathname;
  
  // Extract current subcategory from URL if it exists
  const pathParts = currentPath.split('/');
  const currentSubcategory = pathParts.length > 3 ? pathParts[3] : null;
  
  const subcategories = {
    men: ['New', 'Blazers', 'Shirts', 'Jeans', 'Shoes', 'Outerwear', 'Basics'],
    women: ['New', 'Dresses', 'Blazers', 'Jeans', 'Shoes', 'Outerwear', 'Skirts'],
    kids: ['New', 'T-shirts', 'Denim', 'Shoes', 'Dresses', 'Sweatshirts', 'Basics']
  };

  const titles = {
    men: "Men's Collection",
    women: "Women's Collection",
    kids: "Kids' Collection"
  };
  
  const handleSubcategoryClick = (subcat) => {
    // Update URL without page reload
    const subcatLower = subcat.toLowerCase();
    navigate(`/category/${category}/${subcatLower}`, { replace: true });
    
    // Call the callback to update products
    if (onSubcategoryChange) {
      onSubcategoryChange(subcatLower);
    }
  };

  return (
    <div className="mb-8 sm:mb-12">
      <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center mb-6 sm:mb-10">
        {titles[category] || 'Collection'}
      </h1>
      
      <div className="flex justify-start sm:justify-center overflow-x-auto pb-3 sm:pb-4 max-w-full mx-auto border-b border-primary-200 no-scrollbar">
        <div className="flex space-x-4 sm:space-x-6 md:space-x-8 px-1">
          {subcategories[category]?.map((subcat) => (
            <button 
              key={subcat} 
              onClick={() => handleSubcategoryClick(subcat)}
              className={`category-link whitespace-nowrap pb-2 sm:pb-3 px-1 sm:px-2 text-xs sm:text-sm ${
                currentSubcategory === subcat.toLowerCase() ? 'text-ash-dark font-semibold' : ''
              }`}
            >
              {subcat}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CategoryNav;
