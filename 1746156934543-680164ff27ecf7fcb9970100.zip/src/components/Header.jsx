import React, { useState, useEffect } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Search, ShoppingBag, User } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useSearch } from '../context/SearchContext';
import SearchModal from './SearchModal';

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const { cartItemCount } = useCart();
  const { toggleSearchModal } = useSearch();

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Function to handle logo click - refreshes the page
  const handleLogoClick = () => {
    window.location.href = '/';
  };

  return (
    <header 
      className={`sticky top-0 z-50 transition-all duration-500 ${
        isScrolled ? 'bg-white shadow-sm' : 'bg-transparent'
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Dark overlay that appears on hover - fully transparent when not hovered */}
      <div 
        className={`absolute inset-0 bg-black transition-opacity duration-500 ${
          isHovered && !isScrolled ? 'opacity-70' : 'opacity-0 pointer-events-none'
        }`}
      ></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex items-center h-20">
          {/* Left side - Navigation button only */}
          <div className="flex items-center w-1/4 md:w-1/3 justify-start">
            {/* Navigation Menu Button */}
            <button 
              className={`relative w-10 h-10 flex items-center justify-center ${
                isScrolled || isHovered ? 'text-primary-700 hover:text-ash-dark' : 'text-white hover:text-white'
              }`}
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
            >
              <div className={`hamburger-menu ${mobileMenuOpen ? 'open' : ''}`}>
                <span className="line line-1"></span>
                <span className="line line-2"></span>
                <span className="line line-3"></span>
              </div>
            </button>
          </div>
          
          {/* Centered Logo - Now with responsive font size */}
          <div className="w-1/2 md:w-1/3 flex justify-center">
            <button 
              onClick={handleLogoClick}
              className={`gabriola-font tracking-tight font-bold cursor-pointer ${
                isScrolled || isHovered ? 'text-primary-900' : 'text-white'
              }`}
              style={{ 
                fontSize: 'clamp(30px, 5vw, 50px)', 
                lineHeight: '1', 
                background: 'none', 
                border: 'none', 
                padding: 0 
              }}
            >
              T<span className="text-primary-900">ꓥ</span>SHLUXE
            </button>
          </div>
          
          {/* Right side icons - Search, User, Cart - Now more mobile-friendly */}
          <div className="flex items-center w-1/4 md:w-1/3 justify-end">
            <div className="flex space-x-2 sm:space-x-5">
              <button 
                className={`p-1 sm:p-2 transition-colors touch-action-manipulation ${
                  isScrolled || isHovered ? 'text-primary-700 hover:text-ash-dark' : 'text-white hover:text-white'
                }`}
                onClick={toggleSearchModal}
                aria-label="Search"
              >
                <Search size={20} className="w-5 h-5 sm:w-5 sm:h-5" />
              </button>
              <Link 
                to="/profile" 
                className={`p-1 sm:p-2 transition-colors touch-action-manipulation ${
                  isScrolled || isHovered ? 'text-primary-700 hover:text-ash-dark' : 'text-white hover:text-white'
                }`}
                aria-label="My Account"
              >
                <User size={20} className="w-5 h-5 sm:w-5 sm:h-5" />
              </Link>
              <Link 
                to="/cart" 
                className={`p-1 sm:p-2 transition-colors relative touch-action-manipulation ${
                  isScrolled || isHovered ? 'text-primary-700 hover:text-ash-dark' : 'text-white hover:text-white'
                }`}
                aria-label="Shopping Cart"
              >
                <ShoppingBag size={20} className="w-5 h-5 sm:w-5 sm:h-5" />
                {cartItemCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-ash-dark text-white text-xs w-4 h-4 sm:w-5 sm:h-5 flex items-center justify-center rounded-full">
                    {cartItemCount > 99 ? '99+' : cartItemCount}
                  </span>
                )}
              </Link>
            </div>
          </div>
        </div>
        
        {/* Desktop Navigation - Below the logo */}
        <nav className={`hidden md:flex items-center justify-center space-x-8 pb-4 ${
          !isScrolled && !isHovered ? 'nav-transparent' : ''
        }`}>
          <NavLink 
            to="/category/men" 
            className={({ isActive }) => 
              `nav-link uppercase tracking-widest text-sm ${
                isActive 
                  ? 'text-ash-dark font-semibold' 
                  : isScrolled || isHovered 
                    ? 'text-primary-700' 
                    : 'text-white'
              }`
            }
          >
            Men
          </NavLink>
          <NavLink 
            to="/category/women" 
            className={({ isActive }) => 
              `nav-link uppercase tracking-widest text-sm ${
                isActive 
                  ? 'text-ash-dark font-semibold' 
                  : isScrolled || isHovered 
                    ? 'text-primary-700' 
                    : 'text-white'
              }`
            }
          >
            Women
          </NavLink>
          <NavLink 
            to="/category/kids" 
            className={({ isActive }) => 
              `nav-link uppercase tracking-widest text-sm ${
                isActive 
                  ? 'text-ash-dark font-semibold' 
                  : isScrolled || isHovered 
                    ? 'text-primary-700' 
                    : 'text-white'
              }`
            }
          >
            Kids
          </NavLink>
          <NavLink 
            to="/new-arrivals" 
            className={({ isActive }) => 
              `nav-link uppercase tracking-widest text-sm ${
                isActive 
                  ? 'text-ash-dark font-semibold' 
                  : isScrolled || isHovered 
                    ? 'text-primary-700' 
                    : 'text-white'
              }`
            }
          >
            New Arrivals
          </NavLink>
          {/* Wishlist link moved to main navigation */}
          <NavLink 
            to="/wishlist" 
            className={({ isActive }) => 
              `nav-link uppercase tracking-widest text-sm ${
                isActive 
                  ? 'text-ash-dark font-semibold' 
                  : isScrolled || isHovered 
                    ? 'text-primary-700' 
                    : 'text-white'
              }`
            }
          >
            Wishlist
          </NavLink>
        </nav>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="bg-white shadow-lg px-4 py-5 relative z-10">
          <nav className="flex flex-col space-y-5">
            <NavLink 
              to="/category/men" 
              className={({ isActive }) => 
                `py-2 uppercase tracking-widest text-sm ${isActive ? 'text-ash-dark font-semibold' : 'text-primary-700'}`
              }
              onClick={() => setMobileMenuOpen(false)}
            >
              Men
            </NavLink>
            <NavLink 
              to="/category/women" 
              className={({ isActive }) => 
                `py-2 uppercase tracking-widest text-sm ${isActive ? 'text-ash-dark font-semibold' : 'text-primary-700'}`
              }
              onClick={() => setMobileMenuOpen(false)}
            >
              Women
            </NavLink>
            <NavLink 
              to="/category/kids" 
              className={({ isActive }) => 
                `py-2 uppercase tracking-widest text-sm ${isActive ? 'text-ash-dark font-semibold' : 'text-primary-700'}`
              }
              onClick={() => setMobileMenuOpen(false)}
            >
              Kids
            </NavLink>
            <NavLink 
              to="/new-arrivals" 
              className={({ isActive }) => 
                `py-2 uppercase tracking-widest text-sm ${isActive ? 'text-ash-dark font-semibold' : 'text-primary-700'}`
              }
              onClick={() => setMobileMenuOpen(false)}
            >
              New Arrivals
            </NavLink>
            {/* Wishlist link added to mobile menu */}
            <NavLink 
              to="/wishlist" 
              className={({ isActive }) => 
                `py-2 uppercase tracking-widest text-sm ${isActive ? 'text-ash-dark font-semibold' : 'text-primary-700'}`
              }
              onClick={() => setMobileMenuOpen(false)}
            >
              Wishlist
            </NavLink>
          </nav>
        </div>
      )}
      
      {/* Search Modal */}
      <SearchModal />
    </header>
  );
};

export default Header;
