import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, ShoppingBag } from 'lucide-react';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';

const ProductCard = ({ product }) => {
  const [imageError, setImageError] = useState(false);
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const { addToCart } = useCart();
  const [showWishlistTooltip, setShowWishlistTooltip] = useState(false);
  const [showCartTooltip, setShowCartTooltip] = useState(false);
  const [selectedSize, setSelectedSize] = useState('M'); // Default size
  
  if (!product) return null;
  
  // Fallback image if the original image fails to load
  const fallbackImage = "https://images.unsplash.com/photo-1561526116-e2460f4d40a9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80";
  
  const handleImageError = () => {
    setImageError(true);
  };
  
  const handleWishlistClick = (e) => {
    e.preventDefault(); // Prevent navigating to product page
    
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
    
    // Show tooltip
    setShowWishlistTooltip(true);
    setTimeout(() => setShowWishlistTooltip(false), 2000);
  };
  
  const handleAddToCart = (e) => {
    e.preventDefault(); // Prevent navigating to product page
    addToCart(product, selectedSize, 1);
    
    // Show tooltip
    setShowCartTooltip(true);
    setTimeout(() => setShowCartTooltip(false), 2000);
  };
  
  const inWishlist = isInWishlist(product.id);
  
  return (
    <div className="group relative bg-white rounded-lg overflow-hidden transition-all duration-300 hover:shadow-lg">
      <div className="relative aspect-[3/4] overflow-hidden">
        <Link to={`/product/${product.id}`}>
          <img 
            src={imageError ? fallbackImage : product.image} 
            alt={product.name} 
            className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
            onError={handleImageError}
          />
        </Link>
        
        {/* Quick action buttons - more compact for mobile */}
        <div className="absolute bottom-2 right-2 flex flex-col space-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <button 
            className="bg-white text-primary-900 p-2 rounded-full shadow-md hover:bg-accent hover:text-white transition-colors"
            onClick={handleAddToCart}
            aria-label="Add to cart"
          >
            <ShoppingBag size={16} />
          </button>
          <button 
            className={`p-2 rounded-full shadow-md transition-colors ${
              inWishlist 
                ? 'bg-accent text-white' 
                : 'bg-white text-primary-900 hover:bg-accent hover:text-white'
            }`}
            onClick={handleWishlistClick}
            aria-label={inWishlist ? "Remove from wishlist" : "Add to wishlist"}
          >
            <Heart size={16} fill={inWishlist ? "currentColor" : "none"} />
          </button>
        </div>
        
        {/* New tag */}
        {product.isNew && (
          <div className="absolute top-2 left-2 bg-accent text-white text-xs font-medium px-2 py-1 rounded">
            NEW
          </div>
        )}
        
        {/* Tooltips */}
        {showWishlistTooltip && (
          <div className="absolute top-2 right-2 bg-primary-900 text-white py-1 px-2 rounded text-xs z-10 whitespace-nowrap">
            {inWishlist ? "Added to wishlist" : "Removed from wishlist"}
          </div>
        )}
        
        {showCartTooltip && (
          <div className="absolute top-2 right-2 bg-primary-900 text-white py-1 px-2 rounded text-xs z-10 whitespace-nowrap">
            Added to cart
          </div>
        )}
      </div>
      
      <div className="p-2 sm:p-3 md:p-4">
        <Link to={`/product/${product.id}`} className="block">
          <h3 className="font-medium text-xs sm:text-sm uppercase mb-1 tracking-wider truncate group-hover:text-accent transition-colors">
            {product.name}
          </h3>
          <p className="text-accent font-semibold text-sm sm:text-base mb-1 sm:mb-2">£{product.price.toFixed(2)}</p>
          <p className="text-primary-600 text-xs leading-relaxed line-clamp-2 h-8 sm:h-10 overflow-hidden">
            {product.description}
          </p>
        </Link>
      </div>
    </div>
  );
};

export default ProductCard;
