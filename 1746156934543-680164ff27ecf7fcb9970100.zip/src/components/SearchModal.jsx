import React, { useEffect, useRef, useState } from 'react';
import { useSearch } from '../context/SearchContext';
import { Link } from 'react-router-dom';
import { X, Search, Loader } from 'lucide-react';
import ProductCard from './ProductCard';

const SearchModal = () => {
  const { 
    searchQuery, 
    searchResults, 
    isSearching, 
    showSearchModal, 
    performSearch, 
    clearSearch, 
    closeSearchModal 
  } = useSearch();
  
  const [inputValue, setInputValue] = useState('');
  const searchInputRef = useRef(null);
  
  // Focus input when modal opens
  useEffect(() => {
    if (showSearchModal && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [showSearchModal]);
  
  // Handle input change with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (inputValue !== searchQuery) {
        performSearch(inputValue);
      }
    }, 300); // 300ms debounce
    
    return () => clearTimeout(timer);
  }, [inputValue, performSearch, searchQuery]);
  
  // Handle escape key to close modal
  useEffect(() => {
    const handleEscKey = (e) => {
      if (e.key === 'Escape') {
        closeSearchModal();
      }
    };
    
    if (showSearchModal) {
      document.addEventListener('keydown', handleEscKey);
    }
    
    return () => {
      document.removeEventListener('keydown', handleEscKey);
    };
  }, [showSearchModal, closeSearchModal]);
  
  // Handle click outside to close modal
  const modalContentRef = useRef(null);
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (modalContentRef.current && !modalContentRef.current.contains(e.target)) {
        closeSearchModal();
      }
    };
    
    if (showSearchModal) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showSearchModal, closeSearchModal]);
  
  if (!showSearchModal) return null;
  
  const handleClearInput = () => {
    setInputValue('');
    clearSearch();
    searchInputRef.current.focus();
  };
  
  const handleProductClick = () => {
    closeSearchModal();
  };
  
  return (
    <div className="fixed inset-0 bg-white z-50 pt-16 md:pt-20">
      <div 
        ref={modalContentRef}
        className="container mx-auto px-4 md:px-8 h-full flex flex-col"
      >
        {/* Search input */}
        <div className="py-6 border-b border-primary-200">
          <div className="relative max-w-3xl mx-auto">
            <input
              ref={searchInputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Search for products..."
              className="w-full py-3 pl-12 pr-10 border-b border-primary-300 focus:outline-none focus:border-primary-900 text-lg"
            />
            <Search className="absolute left-0 top-1/2 transform -translate-y-1/2 text-primary-500" size={20} />
            
            {inputValue && (
              <button 
                onClick={handleClearInput}
                className="absolute right-0 top-1/2 transform -translate-y-1/2 text-primary-500 hover:text-primary-900"
              >
                <X size={20} />
              </button>
            )}
          </div>
        </div>
        
        {/* Search results */}
        <div className="overflow-y-auto flex-grow py-6">
          {isSearching ? (
            <div className="flex justify-center items-center py-12">
              <Loader size={24} className="animate-spin text-primary-900" />
            </div>
          ) : searchQuery && searchResults.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-lg font-light mb-2">No products found</p>
              <p className="text-primary-600 text-sm">Try a different search term</p>
            </div>
          ) : searchResults.length > 0 ? (
            <div className="max-w-6xl mx-auto">
              <p className="mb-6 text-sm text-primary-600">{searchResults.length} products found</p>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-4 gap-y-10">
                {searchResults.map(product => (
                  <div key={product.id} onClick={handleProductClick}>
                    <ProductCard product={product} />
                  </div>
                ))}
              </div>
            </div>
          ) : null}
        </div>
        
        {/* Close button */}
        <div className="absolute top-4 right-4 md:top-8 md:right-8">
          <button 
            onClick={closeSearchModal}
            className="p-2 text-primary-900 hover:text-primary-600"
            aria-label="Close search"
          >
            <X size={24} strokeWidth={1.5} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default SearchModal;
