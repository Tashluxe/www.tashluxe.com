import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import CategoryPage from './pages/CategoryPage';
import ProductPage from './pages/ProductPage';
import CartPage from './pages/CartPage';
import WishlistPage from './pages/WishlistPage';
import ContactPage from './pages/help/ContactPage';
import ShippingPage from './pages/help/ShippingPage';
import ReturnsPage from './pages/help/ReturnsPage';
import PaymentPage from './pages/help/PaymentPage';
import FAQPage from './pages/help/FAQPage';
import PrivacyPolicy from './pages/legal/PrivacyPolicy';
import TermsConditions from './pages/legal/TermsConditions';
import CookiePolicy from './pages/legal/CookiePolicy';
import Accessibility from './pages/legal/Accessibility';
import { CartProvider } from './context/CartContext';
import { SearchProvider } from './context/SearchContext';
import { WishlistProvider } from './context/WishlistContext';

const App = () => {
  return (
    <CartProvider>
      <SearchProvider>
        <WishlistProvider>
          <div className="flex flex-col min-h-screen">
            <Header />
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/category/:category" element={<CategoryPage />} />
                <Route path="/category/:category/:subcategory" element={<CategoryPage />} />
                <Route path="/product/:id" element={<ProductPage />} />
                <Route path="/new-arrivals" element={<CategoryPage category="new" />} />
                <Route path="/wishlist" element={<WishlistPage />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/help/contact" element={<ContactPage />} />
                <Route path="/help/shipping" element={<ShippingPage />} />
                <Route path="/help/returns" element={<ReturnsPage />} />
                <Route path="/help/payment" element={<PaymentPage />} />
                <Route path="/help/faq" element={<FAQPage />} />
                <Route path="/privacy" element={<PrivacyPolicy />} />
                <Route path="/terms" element={<TermsConditions />} />
                <Route path="/cookies" element={<CookiePolicy />} />
                <Route path="/accessibility" element={<Accessibility />} />
                <Route path="/profile" element={<div className="container mx-auto px-4 py-16"><h1 className="text-3xl font-bold mb-6">My Account</h1><p>Please sign in to view your account.</p></div>} />
                <Route path="*" element={<div className="container mx-auto px-4 py-16 text-center"><h1 className="text-3xl font-bold mb-6">Page Not Found</h1><p>The page you are looking for does not exist.</p></div>} />
              </Routes>
            </main>
            <Footer />
          </div>
        </WishlistProvider>
      </SearchProvider>
    </CartProvider>
  );
};

export default App;
