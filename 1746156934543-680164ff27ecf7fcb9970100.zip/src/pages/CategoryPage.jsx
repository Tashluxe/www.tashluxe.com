import React, { useState, useEffect } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { getProductsByCategory, getFeaturedProducts } from '../lib/products';
import { applyFilters } from '../lib/productFilters';
import ProductGrid from '../components/ProductGrid';
import CategoryNav from '../components/CategoryNav';
import { Filter, ChevronDown, ChevronUp, Loader } from 'lucide-react';

const CategoryPage = ({ category: propCategory }) => {
  const params = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  
  // Extract category and subcategory from URL
  const category = propCategory || params.category;
  const pathParts = location.pathname.split('/');
  const subcategory = pathParts.length > 3 ? pathParts[3] : null;
  
  // State for products and loading
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);
  
  // Filter states
  const [selectedSize, setSelectedSize] = useState(null);
  const [selectedPrice, setSelectedPrice] = useState(null);
  const [selectedColor, setSelectedColor] = useState(null);
  const [sortBy, setSortBy] = useState('newest');
  
  // Load products based on category, subcategory and filters
  useEffect(() => {
    setLoading(true);
    
    // Simulate AJAX delay
    const timer = setTimeout(() => {
      let filteredProducts;
      
      if (category === "new") {
        filteredProducts = getFeaturedProducts().slice(0, 8);
      } else {
        // Apply all filters
        filteredProducts = applyFilters(category, subcategory, {
          size: selectedSize,
          price: selectedPrice,
          color: selectedColor,
          sortBy: sortBy
        });
      }
      
      setProducts(filteredProducts);
      setLoading(false);
    }, 500); // Simulate network delay
    
    return () => clearTimeout(timer);
  }, [category, subcategory, selectedSize, selectedPrice, selectedColor, sortBy]);
  
  // Handle subcategory change from CategoryNav
  const handleSubcategoryChange = (newSubcategory) => {
    // Reset filters when changing subcategory
    setSelectedSize(null);
    setSelectedPrice(null);
    setSelectedColor(null);
    setSortBy('newest');
  };
  
  // Handle filter changes
  const handleSizeChange = (size) => {
    setSelectedSize(size === selectedSize ? null : size);
  };
  
  const handlePriceChange = (price) => {
    setSelectedPrice(price === selectedPrice ? null : price);
  };
  
  const handleColorChange = (color) => {
    setSelectedColor(color === selectedColor ? null : color);
  };
  
  const handleSortChange = (event) => {
    setSortBy(event.target.value);
  };
  
  // Reset all filters
  const resetFilters = () => {
    setSelectedSize(null);
    setSelectedPrice(null);
    setSelectedColor(null);
    setSortBy('newest');
  };
  
  const pageTitle = category === "new" 
    ? "New Arrivals" 
    : category === "men" 
      ? "Men's Collection" 
      : category === "women" 
        ? "Women's Collection" 
        : category === "kids" 
          ? "Kids' Collection" 
          : "Collection";
  
  return (
    <div className="container mx-auto px-4 py-8 sm:py-12 md:py-16">
      {category !== "new" ? (
        <CategoryNav 
          category={category} 
          onSubcategoryChange={handleSubcategoryChange} 
        />
      ) : (
        <div className="mb-8 sm:mb-12">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center mb-6 sm:mb-10">
            {pageTitle}
          </h1>
        </div>
      )}
      
      {/* Filter toggle for mobile */}
      <div className="md:hidden mb-4 sm:mb-6">
        <button 
          className="w-full py-2 sm:py-3 px-3 sm:px-4 bg-primary-100 flex items-center justify-between rounded-lg"
          onClick={() => setFiltersOpen(!filtersOpen)}
        >
          <span className="flex items-center">
            <Filter size={16} className="mr-2" />
            Filter & Sort
          </span>
          {filtersOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4 sm:gap-6 md:gap-8">
        {/* Filters - desktop always visible, mobile conditional */}
        <div className={`md:w-64 ${filtersOpen ? 'block' : 'hidden md:block'}`}>
          <div className="bg-white p-4 sm:p-6 rounded-lg shadow-sm">
            <div className="flex justify-between items-center mb-4 sm:mb-6">
              <h3 className="text-base sm:text-lg font-bold">Filters</h3>
              <button 
                className="text-xs sm:text-sm text-accent hover:underline"
                onClick={resetFilters}
              >
                Reset All
              </button>
            </div>
            
            <div className="mb-6 sm:mb-8">
              <h4 className="text-xs sm:text-sm font-semibold uppercase mb-3 sm:mb-4">Size</h4>
              <div className="space-y-2 sm:space-y-3">
                {['XS', 'S', 'M', 'L', 'XL'].map(size => (
                  <div className="flex items-center" key={size}>
                    <input 
                      type="checkbox" 
                      id={`size-${size.toLowerCase()}`} 
                      className="mr-2 sm:mr-3 h-3 w-3 sm:h-4 sm:w-4 accent-accent"
                      checked={selectedSize === size.toLowerCase()}
                      onChange={() => handleSizeChange(size.toLowerCase())}
                    />
                    <label htmlFor={`size-${size.toLowerCase()}`} className="text-xs sm:text-sm">{size}</label>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="mb-6 sm:mb-8">
              <h4 className="text-xs sm:text-sm font-semibold uppercase mb-3 sm:mb-4">Color</h4>
              <div className="flex flex-wrap gap-2 sm:gap-3">
                {[
                  { name: 'black', color: 'bg-black' },
                  { name: 'white', color: 'bg-white border border-gray-300' },
                  { name: 'red', color: 'bg-red-500' },
                  { name: 'blue', color: 'bg-blue-500' },
                  { name: 'green', color: 'bg-green-500' },
                  { name: 'yellow', color: 'bg-yellow-500' }
                ].map(colorObj => (
                  <button 
                    key={colorObj.name}
                    className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full ${colorObj.color} ${
                      selectedColor === colorObj.name 
                        ? 'ring-2 ring-accent ring-offset-2' 
                        : 'border-2 border-transparent hover:border-accent focus:border-accent'
                    }`}
                    onClick={() => handleColorChange(colorObj.name)}
                    aria-label={`Select ${colorObj.name} color`}
                  ></button>
                ))}
              </div>
            </div>
            
            <div className="mb-6 sm:mb-8">
              <h4 className="text-xs sm:text-sm font-semibold uppercase mb-3 sm:mb-4">Price</h4>
              <div className="space-y-2 sm:space-y-3">
                {[
                  { id: 'under-50', label: 'Under £50' },
                  { id: '50-100', label: '£50 - £100' },
                  { id: '100-150', label: '£100 - £150' },
                  { id: '150-200', label: '£150 - £200' },
                  { id: 'over-200', label: 'Over £200' }
                ].map(priceRange => (
                  <div className="flex items-center" key={priceRange.id}>
                    <input 
                      type="checkbox" 
                      id={`price-${priceRange.id}`} 
                      className="mr-2 sm:mr-3 h-3 w-3 sm:h-4 sm:w-4 accent-accent"
                      checked={selectedPrice === priceRange.id}
                      onChange={() => handlePriceChange(priceRange.id)}
                    />
                    <label htmlFor={`price-${priceRange.id}`} className="text-xs sm:text-sm">{priceRange.label}</label>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-xs sm:text-sm font-semibold uppercase mb-3 sm:mb-4">Sort By</h4>
              <div className="space-y-2 sm:space-y-3">
                {[
                  { id: 'newest', label: 'Newest' },
                  { id: 'price-low-high', label: 'Price: Low to High' },
                  { id: 'price-high-low', label: 'Price: High to Low' }
                ].map(sortOption => (
                  <div className="flex items-center" key={sortOption.id}>
                    <input 
                      type="radio" 
                      name="sort" 
                      id={`sort-${sortOption.id}`} 
                      className="mr-2 sm:mr-3 h-3 w-3 sm:h-4 sm:w-4 accent-accent"
                      checked={sortBy === sortOption.id}
                      onChange={() => setSortBy(sortOption.id)}
                    />
                    <label htmlFor={`sort-${sortOption.id}`} className="text-xs sm:text-sm">{sortOption.label}</label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Products */}
        <div className="flex-1">
          <div className="mb-4 sm:mb-6 flex justify-between items-center">
            <p className="text-primary-600 text-xs sm:text-sm">{products.length} products</p>
            <select 
              className="border border-primary-300 rounded-lg px-2 py-1 sm:px-3 sm:py-2 text-xs sm:text-sm"
              value={sortBy}
              onChange={handleSortChange}
            >
              <option value="newest">Newest</option>
              <option value="price-low-high">Price: Low to High</option>
              <option value="price-high-low">Price: High to Low</option>
            </select>
          </div>
          
          {loading ? (
            <div className="flex justify-center items-center h-40 sm:h-64">
              <Loader size={24} className="animate-spin text-accent" />
            </div>
          ) : products.length > 0 ? (
            <ProductGrid products={products} />
          ) : (
            <div className="text-center py-10 sm:py-16">
              <h3 className="text-lg sm:text-xl font-semibold mb-2">No products found</h3>
              <p className="text-primary-600 text-sm mb-4 sm:mb-6">Try adjusting your filters or browse our other categories.</p>
              <button 
                className="text-accent hover:underline text-sm sm:text-base"
                onClick={resetFilters}
              >
                Reset Filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CategoryPage;
