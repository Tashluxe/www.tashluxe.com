import React from 'react';
import { ArrowLeft, CreditCard, Shield, AlertCircle, DollarSign } from 'lucide-react';
import { Link } from 'react-router-dom';

const PaymentPage = () => {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-3xl mx-auto">
        <Link to="/" className="inline-flex items-center text-primary-700 hover:text-accent mb-8">
          <ArrowLeft size={16} className="mr-2" />
          Back to Home
        </Link>
        
        <h1 className="text-3xl font-bold mb-2">Payment Methods</h1>
        <p className="text-primary-600 mb-8">Information about our accepted payment methods, security, and billing.</p>
        
        <div className="bg-primary-50 p-8 rounded-lg mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <div className="flex items-start mb-6">
                <CreditCard size={24} className="text-accent mr-4 mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Multiple Payment Options</h3>
                  <p className="text-primary-600 text-sm">
                    Credit/debit cards, PayPal, Apple Pay, and more.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Shield size={24} className="text-accent mr-4 mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Secure Transactions</h3>
                  <p className="text-primary-600 text-sm">
                    All payments are encrypted and processed securely.
                  </p>
                </div>
              </div>
            </div>
            
            <div>
              <div className="flex items-start mb-6">
                <DollarSign size={24} className="text-accent mr-4 mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">No Hidden Fees</h3>
                  <p className="text-primary-600 text-sm">
                    Transparent pricing with no surprise charges.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <AlertCircle size={24} className="text-accent mr-4 mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Billing Support</h3>
                  <p className="text-primary-600 text-sm">
                    Dedicated team to assist with payment issues.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Accepted Payment Methods</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-medium mb-4">Credit & Debit Cards</h3>
              <div className="flex flex-wrap gap-4 mb-4">
                <div className="bg-white p-3 rounded-lg border border-primary-200 w-16 h-10 flex items-center justify-center">
                  <span className="font-bold text-primary-900">Visa</span>
                </div>
                <div className="bg-white p-3 rounded-lg border border-primary-200 w-16 h-10 flex items-center justify-center">
                  <span className="font-bold text-primary-900">MC</span>
                </div>
                <div className="bg-white p-3 rounded-lg border border-primary-200 w-16 h-10 flex items-center justify-center">
                  <span className="font-bold text-primary-900">Amex</span>
                </div>
                <div className="bg-white p-3 rounded-lg border border-primary-200 w-16 h-10 flex items-center justify-center">
                  <span className="font-bold text-primary-900">Disc</span>
                </div>
              </div>
              <p className="text-primary-600 text-sm">
                We accept all major credit and debit cards, including Visa, Mastercard, American Express, and Discover. Your card will be charged immediately upon order confirmation.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-4">Digital Wallets</h3>
              <div className="flex flex-wrap gap-4 mb-4">
                <div className="bg-white p-3 rounded-lg border border-primary-200 w-16 h-10 flex items-center justify-center">
                  <span className="font-bold text-primary-900">PayPal</span>
                </div>
                <div className="bg-white p-3 rounded-lg border border-primary-200 w-16 h-10 flex items-center justify-center">
                  <span className="font-bold text-primary-900">Apple</span>
                </div>
                <div className="bg-white p-3 rounded-lg border border-primary-200 w-16 h-10 flex items-center justify-center">
                  <span className="font-bold text-primary-900">GPay</span>
                </div>
              </div>
              <p className="text-primary-600 text-sm">
                For added convenience, we accept PayPal, Apple Pay, and Google Pay. These options allow for quick and secure checkout without entering your card details for each purchase.
              </p>
            </div>
          </div>
          
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-medium mb-4">Gift Cards</h3>
              <p className="text-primary-600 text-sm">
                TꓥSHLUXE gift cards can be used for full or partial payment. Enter your gift card number and PIN during checkout to apply the balance to your order. Gift cards never expire and can be used across multiple purchases.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-4">Store Credit</h3>
              <p className="text-primary-600 text-sm">
                Store credit from returns or exchanges will be automatically applied to your account and can be used for future purchases. You can view your available store credit in your account dashboard.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Payment Security</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="font-medium mb-2">Secure Encryption</h3>
              <p className="text-primary-600 text-sm">
                All payment information is encrypted using industry-standard SSL (Secure Socket Layer) technology. Your payment details are never stored on our servers and are securely transmitted to our payment processors.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">PCI Compliance</h3>
              <p className="text-primary-600 text-sm">
                We are fully PCI DSS (Payment Card Industry Data Security Standard) compliant, ensuring that your payment information is handled according to the highest security standards in the industry.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Fraud Prevention</h3>
              <p className="text-primary-600 text-sm">
                We employ advanced fraud detection systems to protect both our customers and our business. In some cases, we may contact you to verify your order before processing to ensure the security of your account.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Secure Account Management</h3>
              <p className="text-primary-600 text-sm">
                We recommend using strong, unique passwords for your TꓥSHLUXE account and enabling two-factor authentication when available. Never share your account credentials with others.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Billing Information</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="font-medium mb-2">Order Processing</h3>
              <p className="text-primary-600 text-sm">
                Your payment will be processed immediately upon order confirmation. You will receive an email receipt with your order details and payment information. Your credit card statement will show a charge from "TASHLUXE".
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Currency</h3>
              <p className="text-primary-600 text-sm">
                All prices on our website are listed in British Pounds (£). If you're paying with a card issued in a different currency, your bank will convert the amount at their current exchange rate and may charge a foreign transaction fee.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Taxes & Duties</h3>
              <p className="text-primary-600 text-sm">
                For UK orders, VAT is included in the displayed prices. For international orders, additional taxes, duties, and customs fees may apply depending on your country's regulations. These charges are the responsibility of the customer and are not included in our prices.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Billing Address</h3>
              <p className="text-primary-600 text-sm">
                For security purposes, we verify that your billing address matches the address associated with your payment method. Please ensure your billing information is accurate to avoid delays in processing your order.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Frequently Asked Questions</h2>
          
          <div className="space-y-4">
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">When will my card be charged?</h3>
              <p className="text-primary-600 text-sm">
                Your card will be charged immediately when you place your order. If an item is out of stock or there's an issue with your order, we'll issue a refund promptly.
              </p>
            </div>
            
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">Is it safe to save my payment information?</h3>
              <p className="text-primary-600 text-sm">
                Yes, if you choose to save your payment information for future purchases, it is stored securely by our payment processor, not on our servers. You can remove saved payment methods at any time from your account settings.
              </p>
            </div>
            
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">What should I do if my payment is declined?</h3>
              <p className="text-primary-600 text-sm">
                If your payment is declined, first verify that your billing information is correct. If the issue persists, contact your bank or card issuer to ensure there are no restrictions on your account. You can also try an alternative payment method or contact our customer service for assistance.
              </p>
            </div>
            
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">Can I split my payment between multiple methods?</h3>
              <p className="text-primary-600 text-sm">
                Currently, we do not support split payments across multiple payment methods. However, you can use a gift card or store credit for partial payment and cover the remaining balance with another payment method.
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-primary-50 p-6 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Need Help with Payment?</h2>
          <p className="text-primary-600 mb-4">
            If you're experiencing issues with payment or have questions about billing, our customer service team is here to help.
          </p>
          <Link to="/help/contact" className="text-accent hover:underline font-medium">
            Contact Customer Service
          </Link>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;
