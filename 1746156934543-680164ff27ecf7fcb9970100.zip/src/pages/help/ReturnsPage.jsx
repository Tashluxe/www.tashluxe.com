import React from 'react';
import { ArrowLeft, RotateCcw, Clock, AlertCircle, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import Button from '../../components/ui/Button';

const ReturnsPage = () => {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-3xl mx-auto">
        <Link to="/" className="inline-flex items-center text-primary-700 hover:text-accent mb-8">
          <ArrowLeft size={16} className="mr-2" />
          Back to Home
        </Link>
        
        <h1 className="text-3xl font-bold mb-2">Returns & Exchanges</h1>
        <p className="text-primary-600 mb-8">Information about our return policy, exchange process, and refunds.</p>
        
        <div className="bg-primary-50 p-8 rounded-lg mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <div className="flex items-start mb-6">
                <RotateCcw size={24} className="text-accent mr-4 mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">30-Day Returns</h3>
                  <p className="text-primary-600 text-sm">
                    Return or exchange items within 30 days of delivery.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <CheckCircle size={24} className="text-accent mr-4 mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Free Returns</h3>
                  <p className="text-primary-600 text-sm">
                    Free return shipping on all UK orders.
                  </p>
                </div>
              </div>
            </div>
            
            <div>
              <div className="flex items-start mb-6">
                <Clock size={24} className="text-accent mr-4 mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Fast Processing</h3>
                  <p className="text-primary-600 text-sm">
                    Refunds are typically processed within 5-7 business days.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <AlertCircle size={24} className="text-accent mr-4 mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Easy Process</h3>
                  <p className="text-primary-600 text-sm">
                    Simple online return portal for hassle-free returns.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Return Policy</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="font-medium mb-2">Eligibility</h3>
              <p className="text-primary-600 text-sm">
                Items must be returned within 30 days of delivery. All items must be unworn, unwashed, and in their original condition with all tags attached. Items marked as "Final Sale" or purchased during special promotions may not be eligible for return or exchange.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Condition Requirements</h3>
              <p className="text-primary-600 text-sm">
                All returned items must be in their original condition with no signs of wear, damage, or alteration. Items must include all original packaging, tags, dust bags, and accessories. Items that show signs of wear or have been used will not be accepted for return or exchange.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Non-Returnable Items</h3>
              <p className="text-primary-600 text-sm">
                The following items cannot be returned or exchanged:
              </p>
              <ul className="list-disc pl-5 mt-2 text-primary-600 text-sm">
                <li>Underwear, swimwear, and bodysuits for hygiene reasons</li>
                <li>Face masks and personal care items</li>
                <li>Items marked as "Final Sale"</li>
                <li>Gift cards</li>
                <li>Items damaged due to customer misuse</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">International Returns</h3>
              <p className="text-primary-600 text-sm">
                International customers are responsible for return shipping costs and any customs duties or taxes incurred during the return process. Please note that international returns may take longer to process.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">How to Return or Exchange</h2>
          
          <div className="bg-primary-50 p-6 rounded-lg mb-8">
            <h3 className="font-medium mb-4">Return Process</h3>
            <ol className="space-y-4">
              <li className="flex">
                <span className="flex-shrink-0 w-6 h-6 bg-accent text-white rounded-full flex items-center justify-center mr-3">1</span>
                <div>
                  <p className="text-primary-600 text-sm">
                    <strong>Initiate your return</strong> - Log into your account and go to "Order History" to find the order you wish to return. Select "Return Items" and follow the instructions.
                  </p>
                </div>
              </li>
              
              <li className="flex">
                <span className="flex-shrink-0 w-6 h-6 bg-accent text-white rounded-full flex items-center justify-center mr-3">2</span>
                <div>
                  <p className="text-primary-600 text-sm">
                    <strong>Print your return label</strong> - Once your return is approved, you'll receive a return shipping label via email. Print this label and attach it to your package.
                  </p>
                </div>
              </li>
              
              <li className="flex">
                <span className="flex-shrink-0 w-6 h-6 bg-accent text-white rounded-full flex items-center justify-center mr-3">3</span>
                <div>
                  <p className="text-primary-600 text-sm">
                    <strong>Package your items</strong> - Place the items in their original packaging or a secure box. Include all tags, accessories, and the original receipt or packing slip.
                  </p>
                </div>
              </li>
              
              <li className="flex">
                <span className="flex-shrink-0 w-6 h-6 bg-accent text-white rounded-full flex items-center justify-center mr-3">4</span>
                <div>
                  <p className="text-primary-600 text-sm">
                    <strong>Ship your return</strong> - Drop off your package at any authorized shipping location. We recommend keeping the tracking number for your records.
                  </p>
                </div>
              </li>
              
              <li className="flex">
                <span className="flex-shrink-0 w-6 h-6 bg-accent text-white rounded-full flex items-center justify-center mr-3">5</span>
                <div>
                  <p className="text-primary-600 text-sm">
                    <strong>Receive your refund</strong> - Once we receive and inspect your return, we'll process your refund to your original payment method. This typically takes 5-7 business days.
                  </p>
                </div>
              </li>
            </ol>
          </div>
          
          <div className="bg-primary-50 p-6 rounded-lg">
            <h3 className="font-medium mb-4">Exchange Process</h3>
            <ol className="space-y-4">
              <li className="flex">
                <span className="flex-shrink-0 w-6 h-6 bg-accent text-white rounded-full flex items-center justify-center mr-3">1</span>
                <div>
                  <p className="text-primary-600 text-sm">
                    <strong>Initiate your exchange</strong> - Log into your account and go to "Order History" to find the order you wish to exchange. Select "Exchange Items" and follow the instructions.
                  </p>
                </div>
              </li>
              
              <li className="flex">
                <span className="flex-shrink-0 w-6 h-6 bg-accent text-white rounded-full flex items-center justify-center mr-3">2</span>
                <div>
                  <p className="text-primary-600 text-sm">
                    <strong>Select your new item</strong> - Choose the size, color, or alternative item you'd like to receive in exchange.
                  </p>
                </div>
              </li>
              
              <li className="flex">
                <span className="flex-shrink-0 w-6 h-6 bg-accent text-white rounded-full flex items-center justify-center mr-3">3</span>
                <div>
                  <p className="text-primary-600 text-sm">
                    <strong>Print your exchange label</strong> - Once your exchange is approved, you'll receive a return shipping label via email. Print this label and attach it to your package.
                  </p>
                </div>
              </li>
              
              <li className="flex">
                <span className="flex-shrink-0 w-6 h-6 bg-accent text-white rounded-full flex items-center justify-center mr-3">4</span>
                <div>
                  <p className="text-primary-600 text-sm">
                    <strong>Ship your exchange</strong> - Package your items securely and drop off at any authorized shipping location.
                  </p>
                </div>
              </li>
              
              <li className="flex">
                <span className="flex-shrink-0 w-6 h-6 bg-accent text-white rounded-full flex items-center justify-center mr-3">5</span>
                <div>
                  <p className="text-primary-600 text-sm">
                    <strong>Receive your new item</strong> - Once we receive and inspect your return, we'll ship your exchange item. You'll receive a shipping confirmation email with tracking information.
                  </p>
                </div>
              </li>
            </ol>
          </div>
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Refund Information</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="font-medium mb-2">Refund Processing</h3>
              <p className="text-primary-600 text-sm">
                Once we receive and inspect your return, we'll process your refund to your original payment method. This typically takes 5-7 business days. You'll receive an email notification when your refund has been processed.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Refund Methods</h3>
              <p className="text-primary-600 text-sm">
                Refunds will be issued to the original payment method used for the purchase. If the original payment method is no longer available, we'll issue a store credit.
              </p>
              <ul className="list-disc pl-5 mt-2 text-primary-600 text-sm">
                <li>Credit/Debit Card: 5-7 business days</li>
                <li>PayPal: 3-5 business days</li>
                <li>Store Credit: Immediate</li>
                <li>Gift Card: Immediate</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Partial Refunds</h3>
              <p className="text-primary-600 text-sm">
                We may issue partial refunds for items that show signs of wear, damage, or if parts of a set are missing. The refund amount will be determined based on the condition of the returned item.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Shipping Costs</h3>
              <p className="text-primary-600 text-sm">
                Original shipping costs are non-refundable unless the return is due to our error (damaged item, wrong item shipped, etc.). If you received free shipping on your original order, the standard shipping cost will be deducted from your refund.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Frequently Asked Questions</h2>
          
          <div className="space-y-4">
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">How long do I have to return an item?</h3>
              <p className="text-primary-600 text-sm">
                You have 30 days from the delivery date to return or exchange an item. After this period, returns and exchanges will not be accepted.
              </p>
            </div>
            
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">Can I return a gift?</h3>
              <p className="text-primary-600 text-sm">
                Yes, gifts can be returned for store credit or exchanged for another item. You'll need the order number or gift receipt to process the return. The refund will be issued as store credit to the gift recipient.
              </p>
            </div>
            
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">What if my item is damaged or defective?</h3>
              <p className="text-primary-600 text-sm">
                If you receive a damaged or defective item, please contact our customer service team within 48 hours of delivery. We'll arrange for a return or replacement at no cost to you.
              </p>
            </div>
            
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">Can I return sale items?</h3>
              <p className="text-primary-600 text-sm">
                Most sale items can be returned within 30 days, unless they are marked as "Final Sale." Final Sale items cannot be returned or exchanged.
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row gap-6">
          <div className="flex-1 bg-primary-50 p-6 rounded-lg">
            <h2 className="text-xl font-semibold mb-4">Start a Return</h2>
            <p className="text-primary-600 mb-4">
              Ready to return or exchange an item? Start the process online through your account.
            </p>
            <Button variant="primary">
              Initiate Return
            </Button>
          </div>
          
          <div className="flex-1 bg-primary-50 p-6 rounded-lg">
            <h2 className="text-xl font-semibold mb-4">Need Help?</h2>
            <p className="text-primary-600 mb-4">
              If you have any questions about returns or exchanges, our customer service team is here to help.
            </p>
            <Link to="/help/contact">
              <Button variant="secondary">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReturnsPage;
