import React, { useState } from 'react';
import { ArrowLeft, ChevronDown, ChevronUp, Search } from 'lucide-react';
import { Link } from 'react-router-dom';

const FAQPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [expandedQuestions, setExpandedQuestions] = useState({});
  
  // FAQ categories
  const categories = [
    { id: 'all', name: 'All FAQs' },
    { id: 'orders', name: 'Orders & Shipping' },
    { id: 'returns', name: 'Returns & Refunds' },
    { id: 'products', name: 'Products & Sizing' },
    { id: 'account', name: 'Account & Payment' },
  ];
  
  // FAQ data
  const faqs = [
    {
      id: 1,
      question: "How can I track my order?",
      answer: "You can track your order by logging into your account and visiting the 'Order History' section. Alternatively, you can use the tracking number provided in your shipping confirmation email to track your package directly on the courier's website.",
      category: "orders"
    },
    {
      id: 2,
      question: "What is your return policy?",
      answer: "We offer a 30-day return policy for most items. Products must be in their original condition with tags attached. Please visit our Returns & Exchanges page for detailed information on how to initiate a return.",
      category: "returns"
    },
    {
      id: 3,
      question: "How long does shipping take?",
      answer: "Standard shipping typically takes 3-5 business days within the UK, and 7-14 business days for international orders. Express shipping options are available at checkout for faster delivery.",
      category: "orders"
    },
    {
      id: 4,
      question: "Do you offer international shipping?",
      answer: "Yes, we ship to most countries worldwide. Shipping costs and delivery times vary by location. Please note that international orders may be subject to customs duties and taxes, which are the responsibility of the customer.",
      category: "orders"
    },
    {
      id: 5,
      question: "How do I find my size?",
      answer: "You can find detailed size guides on each product page. We provide measurements for all our products to help you find the perfect fit. If you're between sizes, we generally recommend sizing up for a more comfortable fit.",
      category: "products"
    },
    {
      id: 6,
      question: "Can I change or cancel my order?",
      answer: "You can request changes or cancellations within 1 hour of placing your order by contacting our customer service team. After this window, orders are processed for shipping and cannot be modified or cancelled.",
      category: "orders"
    },
    {
      id: 7,
      question: "How do I create an account?",
      answer: "You can create an account by clicking on the 'User' icon in the top right corner of our website and selecting 'Create Account'. You'll need to provide your email address and create a password. You can also create an account during the checkout process.",
      category: "account"
    },
    {
      id: 8,
      question: "What payment methods do you accept?",
      answer: "We accept all major credit and debit cards (Visa, Mastercard, American Express, Discover), PayPal, Apple Pay, and Google Pay. We also accept TꓥSHLUXE gift cards and store credit.",
      category: "account"
    },
    {
      id: 9,
      question: "How do I return an item?",
      answer: "To return an item, log into your account, go to 'Order History', and select the order containing the item you wish to return. Click on 'Return Items' and follow the instructions. You'll receive a return shipping label via email once your return is approved.",
      category: "returns"
    },
    {
      id: 10,
      question: "When will I receive my refund?",
      answer: "Once we receive and inspect your return, we'll process your refund to your original payment method. This typically takes 5-7 business days. You'll receive an email notification when your refund has been processed.",
      category: "returns"
    },
    {
      id: 11,
      question: "Do you offer gift wrapping?",
      answer: "Yes, we offer gift wrapping services for a small additional fee. You can select this option during checkout. We use premium quality paper and include a gift message of your choice.",
      category: "orders"
    },
    {
      id: 12,
      question: "How do I redeem a gift card?",
      answer: "You can redeem a gift card during checkout by entering the gift card number and PIN in the designated field. The balance will be applied to your order total. Gift cards can be used for full or partial payment.",
      category: "account"
    },
    {
      id: 13,
      question: "Are your products sustainable?",
      answer: "We are committed to sustainability and are continuously working to improve our practices. Many of our products use sustainable materials, and we're working towards more eco-friendly packaging and shipping methods. You can learn more on our Sustainability page.",
      category: "products"
    },
    {
      id: 14,
      question: "How do I care for my TꓥSHLUXE products?",
      answer: "Care instructions are provided on the product label and product page for each item. Generally, we recommend washing clothes in cold water and air drying to maintain quality and longevity. For specific materials like cashmere or leather, special care may be required.",
      category: "products"
    },
    {
      id: 15,
      question: "Do you offer price adjustments?",
      answer: "If an item you purchased goes on sale within 14 days of your purchase, we're happy to offer a one-time price adjustment. Please contact our customer service team with your order number to request an adjustment.",
      category: "account"
    },
    {
      id: 16,
      question: "Can I exchange an item for a different size or color?",
      answer: "Yes, you can exchange items for a different size or color within 30 days of delivery. To initiate an exchange, log into your account, go to 'Order History', and select 'Exchange Items'. Follow the instructions to complete the process.",
      category: "returns"
    },
    {
      id: 17,
      question: "How do I check the status of my return or exchange?",
      answer: "You can check the status of your return or exchange by logging into your account and visiting the 'Order History' section. Select the order with the return or exchange to view its current status.",
      category: "returns"
    },
    {
      id: 18,
      question: "Do you have physical stores?",
      answer: "Yes, we have physical stores in major cities across the UK and Europe. You can find your nearest store using our Store Locator tool on our website.",
      category: "products"
    },
    {
      id: 19,
      question: "How do I reset my password?",
      answer: "To reset your password, click on the 'User' icon in the top right corner and select 'Sign In'. Then click on 'Forgot Password' and follow the instructions. We'll send you an email with a link to reset your password.",
      category: "account"
    },
    {
      id: 20,
      question: "Do you offer student discounts?",
      answer: "Yes, we offer a 10% student discount. To verify your student status and receive your discount code, please visit our Student Discount page and follow the verification process.",
      category: "account"
    },
    {
      id: 21,
      question: "How do I use a promo code?",
      answer: "You can apply a promo code during checkout. After adding items to your cart, proceed to checkout and enter your promo code in the designated field. Click 'Apply' to see the discount reflected in your order total.",
      category: "orders"
    },
    {
      id: 22,
      question: "What if my item is damaged or defective?",
      answer: "If you receive a damaged or defective item, please contact our customer service team within 48 hours of delivery. We'll arrange for a return or replacement at no cost to you. Please provide photos of the damage or defect to expedite the process.",
      category: "returns"
    },
    {
      id: 23,
      question: "Can I return sale items?",
      answer: "Most sale items can be returned within 30 days, unless they are marked as 'Final Sale'. Final Sale items cannot be returned or exchanged. The return policy is always indicated on the product page.",
      category: "returns"
    },
    {
      id: 24,
      question: "How do I contact customer service?",
      answer: "You can contact our customer service team through our Contact Us page, by email at support@tashluxe.com, or by phone at +44 20 1234 5678. Our customer service hours are Monday to Friday, 9 AM to 6 PM GMT.",
      category: "account"
    }
  ];
  
  // Toggle question expansion
  const toggleQuestion = (id) => {
    setExpandedQuestions(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };
  
  // Filter FAQs based on search query and active category
  const filteredFaqs = faqs.filter(faq => {
    const matchesSearch = faq.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'all' || faq.category === activeCategory;
    return matchesSearch && matchesCategory;
  });
  
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-3xl mx-auto">
        <Link to="/" className="inline-flex items-center text-primary-700 hover:text-accent mb-8">
          <ArrowLeft size={16} className="mr-2" />
          Back to Home
        </Link>
        
        <h1 className="text-3xl font-bold mb-2">Frequently Asked Questions</h1>
        <p className="text-primary-600 mb-8">Find answers to common questions about our products, orders, shipping, returns, and more.</p>
        
        {/* Search Bar */}
        <div className="relative mb-10">
          <input
            type="text"
            placeholder="Search for answers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-3 pl-12 border border-primary-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
          />
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-primary-400" size={18} />
        </div>
        
        {/* Category Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-4 py-2 rounded-full text-sm ${
                activeCategory === category.id
                  ? 'bg-accent text-white'
                  : 'bg-primary-100 text-primary-700 hover:bg-primary-200'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>
        
        {/* FAQ Accordion */}
        <div className="space-y-4 mb-12">
          {filteredFaqs.length > 0 ? (
            filteredFaqs.map(faq => (
              <div key={faq.id} className="border border-primary-200 rounded-lg overflow-hidden">
                <button
                  onClick={() => toggleQuestion(faq.id)}
                  className="w-full flex justify-between items-center p-5 text-left bg-white hover:bg-primary-50 transition-colors"
                >
                  <h3 className="font-medium pr-8">{faq.question}</h3>
                  {expandedQuestions[faq.id] ? (
                    <ChevronUp size={18} className="flex-shrink-0 text-primary-500" />
                  ) : (
                    <ChevronDown size={18} className="flex-shrink-0 text-primary-500" />
                  )}
                </button>
                
                {expandedQuestions[faq.id] && (
                  <div className="p-5 bg-primary-50 border-t border-primary-200">
                    <p className="text-primary-600">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="text-center py-8 bg-primary-50 rounded-lg">
              <p className="text-primary-600 mb-2">No results found for "{searchQuery}"</p>
              <p className="text-sm">Try using different keywords or browse all categories</p>
            </div>
          )}
        </div>
        
        {/* Still Need Help Section */}
        <div className="bg-primary-50 p-6 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Still Need Help?</h2>
          <p className="text-primary-600 mb-4">
            If you couldn't find the answer to your question, our customer service team is here to help.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link 
              to="/help/contact" 
              className="inline-block bg-accent text-white px-6 py-3 rounded-lg text-sm font-medium hover:bg-ash-dark transition-colors text-center"
            >
              Contact Us
            </Link>
            <Link 
              to="/help/shipping" 
              className="inline-block bg-white border border-primary-300 text-primary-900 px-6 py-3 rounded-lg text-sm font-medium hover:border-accent hover:text-accent transition-colors text-center"
            >
              Shipping Info
            </Link>
            <Link 
              to="/help/returns" 
              className="inline-block bg-white border border-primary-300 text-primary-900 px-6 py-3 rounded-lg text-sm font-medium hover:border-accent hover:text-accent transition-colors text-center"
            >
              Returns Policy
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQPage;
