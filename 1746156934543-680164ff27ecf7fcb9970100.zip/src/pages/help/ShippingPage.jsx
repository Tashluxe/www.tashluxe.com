import React from 'react';
import { ArrowLeft, Truck, Clock, Globe, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const ShippingPage = () => {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-3xl mx-auto">
        <Link to="/" className="inline-flex items-center text-primary-700 hover:text-accent mb-8">
          <ArrowLeft size={16} className="mr-2" />
          Back to Home
        </Link>
        
        <h1 className="text-3xl font-bold mb-2">Shipping & Delivery</h1>
        <p className="text-primary-600 mb-8">Information about our shipping options, delivery times, and policies.</p>
        
        <div className="bg-primary-50 p-8 rounded-lg mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <div className="flex items-start mb-6">
                <Truck size={24} className="text-accent mr-4 mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Free Standard Shipping</h3>
                  <p className="text-primary-600 text-sm">
                    On all orders over £150. Orders under £150 have a flat rate of £10.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Clock size={24} className="text-accent mr-4 mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Fast Processing</h3>
                  <p className="text-primary-600 text-sm">
                    Most orders are processed and shipped within 24-48 hours.
                  </p>
                </div>
              </div>
            </div>
            
            <div>
              <div className="flex items-start mb-6">
                <Globe size={24} className="text-accent mr-4 mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">International Shipping</h3>
                  <p className="text-primary-600 text-sm">
                    We ship to over 100 countries worldwide with competitive rates.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <AlertCircle size={24} className="text-accent mr-4 mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Order Tracking</h3>
                  <p className="text-primary-600 text-sm">
                    Track your order status and location in real-time.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Shipping Options</h2>
          
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-primary-100">
                  <th className="text-left p-4 border border-primary-200">Shipping Method</th>
                  <th className="text-left p-4 border border-primary-200">Delivery Time</th>
                  <th className="text-left p-4 border border-primary-200">Cost</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="p-4 border border-primary-200">Standard Shipping (UK)</td>
                  <td className="p-4 border border-primary-200">3-5 business days</td>
                  <td className="p-4 border border-primary-200">£10 (Free on orders over £150)</td>
                </tr>
                <tr className="bg-primary-50">
                  <td className="p-4 border border-primary-200">Express Shipping (UK)</td>
                  <td className="p-4 border border-primary-200">1-2 business days</td>
                  <td className="p-4 border border-primary-200">£15</td>
                </tr>
                <tr>
                  <td className="p-4 border border-primary-200">Standard International</td>
                  <td className="p-4 border border-primary-200">7-14 business days</td>
                  <td className="p-4 border border-primary-200">From £20 (varies by country)</td>
                </tr>
                <tr className="bg-primary-50">
                  <td className="p-4 border border-primary-200">Express International</td>
                  <td className="p-4 border border-primary-200">3-5 business days</td>
                  <td className="p-4 border border-primary-200">From £35 (varies by country)</td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <p className="text-primary-600 text-sm mt-4">
            * Delivery times are estimates and may vary based on location and other factors.
          </p>
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Shipping Policies</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="font-medium mb-2">Order Processing</h3>
              <p className="text-primary-600 text-sm">
                Orders are typically processed within 24-48 hours after payment confirmation. During sale periods or holidays, processing times may be slightly longer. You will receive a confirmation email once your order has been processed and shipped, including tracking information.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Shipping Restrictions</h3>
              <p className="text-primary-600 text-sm">
                We currently do not ship to P.O. boxes or APO/FPO addresses. Some countries may have import restrictions on certain products. It is the customer's responsibility to be aware of any import restrictions in their country.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">International Shipping</h3>
              <p className="text-primary-600 text-sm">
                International customers may be subject to import duties, taxes, and customs clearance fees. These charges are the responsibility of the recipient and are not included in the shipping cost. Please check with your local customs office for more information before placing your order.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Tracking Your Order</h3>
              <p className="text-primary-600 text-sm">
                Once your order has been shipped, you will receive a confirmation email with tracking information. You can also track your order by logging into your account and visiting the "Order History" section.
              </p>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Delivery Issues</h3>
              <p className="text-primary-600 text-sm">
                If you experience any issues with your delivery, such as damaged packages or missing items, please contact our customer service team within 48 hours of receiving your order. We will work with you to resolve the issue as quickly as possible.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Frequently Asked Questions</h2>
          
          <div className="space-y-4">
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">Can I change my shipping address after placing an order?</h3>
              <p className="text-primary-600 text-sm">
                Address changes can only be accommodated if the order has not yet been processed. Please contact our customer service team as soon as possible if you need to change your shipping address.
              </p>
            </div>
            
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">What happens if I'm not home when my package is delivered?</h3>
              <p className="text-primary-600 text-sm">
                For UK deliveries, if you're not home, the courier will typically leave a note with instructions for rescheduling delivery or collecting from a local depot. For international deliveries, policies vary by country and courier.
              </p>
            </div>
            
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">Do you offer same-day or next-day delivery?</h3>
              <p className="text-primary-600 text-sm">
                We currently offer next-day delivery for orders placed before 1 PM (UK time) Monday through Friday, excluding holidays. This service is available for UK mainland addresses only and at an additional cost.
              </p>
            </div>
            
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">What should I do if my package is lost or stolen?</h3>
              <p className="text-primary-600 text-sm">
                If your tracking information indicates that your package was delivered but you haven't received it, please contact our customer service team within 48 hours. We will work with the shipping carrier to locate your package or process a replacement.
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-primary-50 p-6 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Need More Help?</h2>
          <p className="text-primary-600 mb-4">
            If you have any questions about shipping or delivery that aren't answered here, please don't hesitate to contact our customer service team.
          </p>
          <Link to="/help/contact" className="text-accent hover:underline font-medium">
            Contact Customer Service
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ShippingPage;
