import React, { useState } from 'react';
import { ArrowLeft, Send, Check } from 'lucide-react';
import { Link } from 'react-router-dom';
import Button from '../../components/ui/Button';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    orderNumber: '',
    subject: '',
    message: ''
  });
  
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user types
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };
  
  const validate = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
    }
    
    if (!formData.subject) {
      newErrors.subject = 'Please select a subject';
    }
    
    if (!formData.message.trim()) {
      newErrors.message = 'Message is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validate()) {
      // Simulate form submission
      setTimeout(() => {
        setIsSubmitted(true);
        setFormData({
          name: '',
          email: '',
          orderNumber: '',
          subject: '',
          message: ''
        });
      }, 1000);
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-3xl mx-auto">
        <Link to="/" className="inline-flex items-center text-primary-700 hover:text-accent mb-8">
          <ArrowLeft size={16} className="mr-2" />
          Back to Home
        </Link>
        
        <h1 className="text-3xl font-bold mb-2">Contact Us</h1>
        <p className="text-primary-600 mb-8">We're here to help with any questions or concerns you may have.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="bg-primary-50 p-6 rounded-lg">
            <h3 className="font-semibold mb-3">Customer Support</h3>
            <p className="text-primary-600 text-sm mb-4">For general inquiries and assistance with your orders.</p>
            <p className="text-sm">support@tashluxe.com</p>
            <p className="text-sm">+44 20 1234 5678</p>
          </div>
          
          <div className="bg-primary-50 p-6 rounded-lg">
            <h3 className="font-semibold mb-3">Business Inquiries</h3>
            <p className="text-primary-600 text-sm mb-4">For partnerships, press, and business opportunities.</p>
            <p className="text-sm">business@tashluxe.com</p>
            <p className="text-sm">+44 20 1234 5679</p>
          </div>
          
          <div className="bg-primary-50 p-6 rounded-lg">
            <h3 className="font-semibold mb-3">Store Locations</h3>
            <p className="text-primary-600 text-sm mb-4">Find your nearest TꓥSHLUXE store.</p>
            <Link to="/stores" className="text-accent text-sm hover:underline">
              View Store Locator
            </Link>
          </div>
        </div>
        
        {isSubmitted ? (
          <div className="bg-primary-50 p-8 rounded-lg text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-accent rounded-full mb-4 text-white">
              <Check size={32} />
            </div>
            <h3 className="text-xl font-semibold mb-2">Thank You for Contacting Us</h3>
            <p className="text-primary-600 mb-6">
              We've received your message and will get back to you within 24-48 hours.
            </p>
            <Button variant="primary" onClick={() => setIsSubmitted(false)}>
              Send Another Message
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="bg-primary-50 p-8 rounded-lg">
            <h2 className="text-xl font-semibold mb-6">Send Us a Message</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium mb-2">
                  Full Name <span className="text-accent">*</span>
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border ${errors.name ? 'border-accent' : 'border-primary-300'} rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500`}
                />
                {errors.name && <p className="text-accent text-xs mt-1">{errors.name}</p>}
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium mb-2">
                  Email Address <span className="text-accent">*</span>
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border ${errors.email ? 'border-accent' : 'border-primary-300'} rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500`}
                />
                {errors.email && <p className="text-accent text-xs mt-1">{errors.email}</p>}
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label htmlFor="orderNumber" className="block text-sm font-medium mb-2">
                  Order Number (if applicable)
                </label>
                <input
                  type="text"
                  id="orderNumber"
                  name="orderNumber"
                  value={formData.orderNumber}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-primary-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
              </div>
              
              <div>
                <label htmlFor="subject" className="block text-sm font-medium mb-2">
                  Subject <span className="text-accent">*</span>
                </label>
                <select
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border ${errors.subject ? 'border-accent' : 'border-primary-300'} rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500`}
                >
                  <option value="">Select a subject</option>
                  <option value="order">Order Status</option>
                  <option value="return">Returns & Exchanges</option>
                  <option value="product">Product Information</option>
                  <option value="payment">Payment Issues</option>
                  <option value="other">Other</option>
                </select>
                {errors.subject && <p className="text-accent text-xs mt-1">{errors.subject}</p>}
              </div>
            </div>
            
            <div className="mb-6">
              <label htmlFor="message" className="block text-sm font-medium mb-2">
                Message <span className="text-accent">*</span>
              </label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows="5"
                className={`w-full px-4 py-3 border ${errors.message ? 'border-accent' : 'border-primary-300'} rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500`}
              ></textarea>
              {errors.message && <p className="text-accent text-xs mt-1">{errors.message}</p>}
            </div>
            
            <Button 
              variant="primary" 
              type="submit" 
              className="flex items-center justify-center"
            >
              <Send size={16} className="mr-2" />
              Send Message
            </Button>
          </form>
        )}
        
        <div className="mt-12">
          <h2 className="text-xl font-semibold mb-4">Frequently Asked Questions</h2>
          
          <div className="space-y-4">
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">How can I track my order?</h3>
              <p className="text-primary-600 text-sm">
                You can track your order by logging into your account and visiting the "Order History" section. Alternatively, you can use the tracking number provided in your shipping confirmation email.
              </p>
            </div>
            
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">What is your return policy?</h3>
              <p className="text-primary-600 text-sm">
                We offer a 30-day return policy for most items. Products must be in their original condition with tags attached. Visit our <Link to="/help/returns" className="text-accent hover:underline">Returns & Exchanges</Link> page for more details.
              </p>
            </div>
            
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">How long does shipping take?</h3>
              <p className="text-primary-600 text-sm">
                Standard shipping typically takes 3-5 business days within the UK, and 7-14 business days for international orders. Express shipping options are available at checkout. Visit our <Link to="/help/shipping" className="text-accent hover:underline">Shipping & Delivery</Link> page for more information.
              </p>
            </div>
            
            <div className="border-b border-primary-200 pb-4">
              <h3 className="font-medium mb-2">Do you offer international shipping?</h3>
              <p className="text-primary-600 text-sm">
                Yes, we ship to most countries worldwide. Shipping costs and delivery times vary by location. Please note that international orders may be subject to customs duties and taxes, which are the responsibility of the customer.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
