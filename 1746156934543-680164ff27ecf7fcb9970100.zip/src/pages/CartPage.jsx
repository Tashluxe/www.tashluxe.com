import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import Button from '../components/ui/Button';
import { Trash2, Plus, Minus, ArrowLeft } from 'lucide-react';

const CartPage = () => {
  const { cart, removeFromCart, updateQuantity, cartTotal } = useCart();
  const [imageErrors, setImageErrors] = useState({});

  // Fallback image if the original image fails to load
  const fallbackImage = "https://images.unsplash.com/photo-1561526116-e2460f4d40a9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80";
  
  const handleImageError = (itemId) => {
    setImageErrors(prev => ({
      ...prev,
      [itemId]: true
    }));
  };

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold mb-6">Your Cart</h1>
        <p className="text-primary-600 mb-8">Your cart is empty.</p>
        <Link to="/">
          <Button variant="primary">Continue Shopping</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-3xl font-bold mb-10">Your Cart</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Cart Items - Takes up 2/3 of the space on large screens */}
        <div className="lg:col-span-2">
          <div className="space-y-6">
            {cart.map((item) => (
              <div key={`${item.id}-${item.size}`} className="flex flex-col md:flex-row border border-primary-200 rounded-lg overflow-hidden">
                {/* Product Image */}
                <div className="md:w-1/4 h-40 md:h-auto">
                  <img 
                    src={imageErrors[item.id] ? fallbackImage : item.image} 
                    alt={item.name} 
                    className="w-full h-full object-cover"
                    onError={() => handleImageError(item.id)}
                  />
                </div>
                
                {/* Product Details */}
                <div className="flex-1 p-4 flex flex-col">
                  <div className="flex justify-between mb-2">
                    <h3 className="font-medium">{item.name}</h3>
                    <p className="font-bold text-accent">£{item.price.toFixed(2)}</p>
                  </div>
                  
                  <p className="text-sm text-primary-600 mb-4">Size: {item.size}</p>
                  
                  <div className="mt-auto flex justify-between items-center">
                    {/* Quantity Controls */}
                    <div className="flex items-center border border-primary-300 rounded-lg">
                      <button 
                        className="w-8 h-8 flex items-center justify-center text-primary-600 hover:text-accent"
                        onClick={() => updateQuantity(item.id, item.size, item.quantity - 1)}
                        disabled={item.quantity <= 1}
                        aria-label="Decrease quantity"
                      >
                        <Minus size={16} />
                      </button>
                      <div className="w-10 text-center">{item.quantity}</div>
                      <button 
                        className="w-8 h-8 flex items-center justify-center text-primary-600 hover:text-accent"
                        onClick={() => updateQuantity(item.id, item.size, item.quantity + 1)}
                        aria-label="Increase quantity"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                    
                    {/* Remove Button */}
                    <button 
                      className="text-primary-600 hover:text-accent flex items-center"
                      onClick={() => removeFromCart(item.id, item.size)}
                      aria-label="Remove item"
                    >
                      <Trash2 size={18} className="mr-1" /> Remove
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-8">
            <Link to="/" className="text-primary-700 hover:text-accent flex items-center">
              <ArrowLeft size={16} className="mr-2" /> Continue Shopping
            </Link>
          </div>
        </div>
        
        {/* Order Summary - Takes up 1/3 of the space on large screens */}
        <div className="lg:col-span-1">
          <div className="bg-primary-50 p-6 rounded-lg">
            <h2 className="text-xl font-bold mb-6">Order Summary</h2>
            
            <div className="space-y-3 mb-6">
              <div className="flex justify-between">
                <span className="text-primary-600">Subtotal</span>
                <span>£{cartTotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-primary-600">Shipping</span>
                <span>{cartTotal > 150 ? "Free" : "£10.00"}</span>
              </div>
              {cartTotal <= 150 && (
                <div className="text-xs text-primary-600 mt-1">
                  Add £{(150 - cartTotal).toFixed(2)} more to qualify for free shipping
                </div>
              )}
            </div>
            
            <div className="border-t border-primary-200 pt-4 mb-6">
              <div className="flex justify-between font-bold">
                <span>Total</span>
                <span>£{(cartTotal + (cartTotal > 150 ? 0 : 10)).toFixed(2)}</span>
              </div>
            </div>
            
            <Button variant="primary" className="w-full">
              Proceed to Checkout
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
