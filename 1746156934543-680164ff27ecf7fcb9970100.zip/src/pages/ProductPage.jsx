import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getProductById } from '../lib/products';
import Button from '../components/ui/Button';
import { Heart, ShoppingBag, Truck, RotateCcw, Shield, Check } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';

const ProductPage = () => {
  const { id } = useParams();
  const product = getProductById(id);
  const [selectedSize, setSelectedSize] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [showWishlistTooltip, setShowWishlistTooltip] = useState(false);
  const [showCartTooltip, setShowCartTooltip] = useState(false);
  const [imageError, setImageError] = useState(false);
  
  // Get cart functions from context
  const { addToCart } = useCart();
  
  // Get wishlist functions from context
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Product not found</h2>
        <p className="text-primary-600 mb-6">The requested product does not exist or has been removed.</p>
        <Link to="/">
          <Button variant="primary">Back to Home</Button>
        </Link>
      </div>
    );
  }
  
  // Fallback image if the original image fails to load
  const fallbackImage = "https://images.unsplash.com/photo-1561526116-e2460f4d40a9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80";
  
  const handleImageError = () => {
    setImageError(true);
  };
  
  // Sample sizes for demonstration
  const sizes = ['XS', 'S', 'M', 'L', 'XL'];
  
  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };
  
  const increaseQuantity = () => {
    setQuantity(quantity + 1);
  };
  
  const handleWishlistClick = () => {
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
    
    setShowWishlistTooltip(true);
    setTimeout(() => setShowWishlistTooltip(false), 2000);
  };
  
  const handleAddToCart = () => {
    if (!selectedSize) return;
    
    // Add the product to cart
    addToCart(product, selectedSize, quantity);
    
    // Show success tooltip
    setShowCartTooltip(true);
    setTimeout(() => setShowCartTooltip(false), 2000);
  };
  
  const inWishlist = isInWishlist(product.id);
  
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Product Image */}
        <div className="relative">
          <div className="bg-primary-50 rounded-lg overflow-hidden">
            <img 
              src={imageError ? fallbackImage : product.image} 
              alt={product.name} 
              className="w-full h-auto object-cover"
              onError={handleImageError}
            />
          </div>
          {/* Wishlist button on image */}
          <button 
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-md text-primary-500 hover:text-accent transition-colors"
            aria-label={inWishlist ? "Remove from wishlist" : "Add to wishlist"}
            onClick={handleWishlistClick}
          >
            <Heart size={20} fill={inWishlist ? "currentColor" : "none"} />
          </button>
          {/* Wishlist Tooltip */}
          {showWishlistTooltip && (
            <div className="absolute top-16 right-4 bg-primary-900 text-white py-2 px-4 rounded text-sm">
              {inWishlist ? "Added to wishlist" : "Removed from wishlist"}
            </div>
          )}
          
          {/* New tag */}
          {product.isNew && (
            <div className="absolute top-4 left-4 bg-accent text-white text-xs font-medium px-2 py-1 rounded">
              NEW
            </div>
          )}
        </div>
        
        {/* Product Details */}
        <div>
          <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
          <p className="text-2xl font-bold text-accent mb-6">£{product.price.toFixed(2)}</p>
          
          <p className="text-primary-600 mb-8 leading-relaxed">
            {product.description}
          </p>
          
          {/* Size Selection */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm font-semibold">SIZE</h3>
              <button className="text-xs text-primary-600 underline">Size Guide</button>
            </div>
            <div className="flex flex-wrap gap-3">
              {sizes.map(size => (
                <button
                  key={size}
                  className={`w-12 h-12 flex items-center justify-center border ${
                    selectedSize === size 
                      ? 'border-accent bg-accent text-white' 
                      : 'border-primary-300 hover:border-accent'
                  } rounded-lg transition-colors`}
                  onClick={() => setSelectedSize(size)}
                >
                  {size}
                </button>
              ))}
            </div>
            {!selectedSize && <p className="text-xs text-accent mt-2">Please select a size</p>}
          </div>
          
          {/* Quantity */}
          <div className="mb-8">
            <h3 className="text-sm font-semibold mb-4">QUANTITY</h3>
            <div className="flex items-center border border-primary-300 rounded-lg w-32">
              <button 
                className="w-10 h-10 flex items-center justify-center text-primary-600 hover:text-accent"
                onClick={decreaseQuantity}
                aria-label="Decrease quantity"
              >
                -
              </button>
              <div className="flex-1 text-center">{quantity}</div>
              <button 
                className="w-10 h-10 flex items-center justify-center text-primary-600 hover:text-accent"
                onClick={increaseQuantity}
                aria-label="Increase quantity"
              >
                +
              </button>
            </div>
          </div>
          
          {/* Add to Cart */}
          <div className="mb-10 relative">
            <Button 
              variant="primary" 
              className="w-full flex items-center justify-center"
              disabled={!selectedSize}
              onClick={handleAddToCart}
            >
              <ShoppingBag size={18} className="mr-2" />
              Add to Cart
            </Button>
            
            {/* Cart Success Tooltip */}
            {showCartTooltip && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-primary-900 text-white py-3 px-4 rounded text-sm flex items-center justify-center">
                <Check size={16} className="mr-2" /> Added to cart successfully
              </div>
            )}
          </div>
          
          {/* Shipping & Returns */}
          <div className="space-y-6 border-t border-primary-200 pt-8">
            <div className="flex items-start">
              <Truck size={20} className="text-primary-600 mt-1 mr-3" />
              <div>
                <h3 className="text-sm font-semibold">Free Shipping</h3>
                <p className="text-sm text-primary-600">On orders over £150</p>
              </div>
            </div>
            <div className="flex items-start">
              <RotateCcw size={20} className="text-primary-600 mt-1 mr-3" />
              <div>
                <h3 className="text-sm font-semibold">Free Returns</h3>
                <p className="text-sm text-primary-600">Within 30 days of purchase</p>
              </div>
            </div>
            <div className="flex items-start">
              <Shield size={20} className="text-primary-600 mt-1 mr-3" />
              <div>
                <h3 className="text-sm font-semibold">Secure Payment</h3>
                <p className="text-sm text-primary-600">All major credit cards accepted</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductPage;
