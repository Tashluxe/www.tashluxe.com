import React from 'react';
import { useSearch } from '../context/SearchContext';
import ProductGrid from '../components/ProductGrid';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import EmptyState from '../components/EmptyState';

const SearchResultsPage = () => {
  const { searchQuery, searchResults, isSearching } = useSearch();
  
  if (!searchQuery) {
    return (
      <div className="container mx-auto px-4 py-16">
        <EmptyState 
          title="No search query"
          message="Please use the search bar to find products."
          showResetButton={false}
          showHomeButton={true}
        />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="mb-8">
        <Link to="/" className="text-primary-700 hover:text-accent flex items-center">
          <ArrowLeft size={16} className="mr-2" /> Back to Home
        </Link>
      </div>
      
      <h1 className="text-3xl font-bold mb-6">Search Results</h1>
      <p className="text-primary-600 mb-8">
        {isSearching ? 'Searching...' : `${searchResults.length} results for "${searchQuery}"`}
      </p>
      
      {isSearching ? (
        <div className="flex justify-center items-center py-12">
          <LoadingSpinner size="large" />
        </div>
      ) : searchResults.length === 0 ? (
        <EmptyState 
          title="No products found"
          message={`We couldn't find any products matching "${searchQuery}". Try a different search term or browse our categories.`}
          showResetButton={false}
          showHomeButton={true}
        />
      ) : (
        <ProductGrid products={searchResults} />
      )}
    </div>
  );
};

export default SearchResultsPage;
