import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/ui/Button';
import { ArrowRight } from 'lucide-react';
import CategoryGrid from '../components/CategoryGrid';
import FeaturedProducts from '../components/FeaturedProducts';

const Home = () => {
  const [heroImageError, setHeroImageError] = useState(false);
  const [promoImageError, setPromoImageError] = useState(false);
  
  // High-quality hero images with fallbacks
  const primaryHeroImage = "https://images.unsplash.com/photo-1483985988355-763728e1935b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=100";
  const fallbackHeroImage = "https://images.unsplash.com/photo-1550614000-4895a10e1bfd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2074&q=100";
  
  // Updated Summer Sales promo image with 4K quality
  const primaryPromoImage = "https://images.unsplash.com/photo-1573855619003-97b4799dcd8b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=100";
  const fallbackPromoImage = "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=100";
  
  const handleHeroImageError = () => {
    setHeroImageError(true);
  };
  
  const handlePromoImageError = () => {
    setPromoImageError(true);
  };
  
  return (
    <div>
      {/* Hero Section - Full height with transparent header overlay */}
      <section className="relative h-screen flex items-center -mt-20">
        <div className="absolute inset-0 z-0">
          <img 
            src={heroImageError ? fallbackHeroImage : primaryHeroImage} 
            alt="Luxury fashion" 
            className="w-full h-full object-cover object-center"
            onError={handleHeroImageError}
          />
          {/* Subtle gradient overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/50 via-black/30 to-transparent"></div>
        </div>
        
        <div className="container mx-auto px-4 z-10 text-left max-w-5xl pt-20">
          <div className="max-w-xl">
            <h1 className="text-5xl md:text-7xl text-white font-bold mb-6 leading-tight">
              Elevate Your Style
            </h1>
            <p className="text-white text-xl mb-10 font-light leading-relaxed">
              Discover the latest trends and timeless classics in our new collection.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link to="/category/women">
                <Button variant="primary" className="min-w-[180px] w-full sm:w-auto">Shop Women</Button>
              </Link>
              <Link to="/category/men">
                <Button variant="secondary" className="min-w-[180px] w-full sm:w-auto">Shop Men</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Featured Products - Now appears before Category Grid */}
      <FeaturedProducts />
      
      {/* Category Grid - Now appears after Featured Products */}
      <CategoryGrid />
      
      {/* Promotion Banner - Updated with new 4K image */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="bg-primary-50 rounded-2xl overflow-hidden relative">
            {/* For mobile, show the image above the text instead of to the right */}
            <div className="w-full h-48 md:h-auto md:absolute md:top-0 md:right-0 md:w-1/2 md:h-full block">
              <img 
                src={promoImageError ? fallbackPromoImage : primaryPromoImage} 
                alt="Summer Sale" 
                className="w-full h-full object-cover object-center"
                onError={handlePromoImageError}
              />
            </div>
            <div className="w-full md:w-1/2 p-6 sm:p-8 md:p-12 lg:p-16">
              <h2 className="text-3xl sm:text-4xl font-bold mb-4 sm:mb-6">Summer Sale</h2>
              <p className="text-lg sm:text-xl mb-6 sm:mb-8 leading-relaxed">Up to 10% off on selected items. Limited time offer.</p>
              <Link to="/new-arrivals">
                <Button variant="primary">Shop the Sale</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Sustainability Section */}
      <section className="py-16 sm:py-20 bg-primary-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-2xl sm:text-3xl font-bold mb-4 sm:mb-6">Our Commitment to Sustainability</h2>
            <p className="text-primary-200 text-base sm:text-lg mb-8 sm:mb-10 leading-relaxed">
              We believe in creating fashion that respects our planet. Our commitment to sustainability guides every decision we make, from sourcing materials to our production processes.
            </p>
            <Link to="/category/men">
              <Button variant="secondary">Learn More</Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
