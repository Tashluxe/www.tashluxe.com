import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

const Accessibility = () => {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-3xl mx-auto">
        <Link to="/" className="inline-flex items-center text-primary-700 hover:text-accent mb-8">
          <ArrowLeft size={16} className="mr-2" />
          Back to Home
        </Link>
        
        <h1 className="text-3xl font-bold mb-6">Accessibility Statement</h1>
        <p className="text-primary-600 mb-8">Last Updated: June 1, 2023</p>
        
        <div className="prose max-w-none">
          <p>
            TꓥSHLUXE is committed to ensuring digital accessibility for people with disabilities. We are continually improving the user experience for everyone and applying the relevant accessibility standards.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Our Commitment to Accessibility</h2>
          <p>
            We strive to ensure that our website conforms to level AA of the World Wide Web Consortium (W3C) Web Content Accessibility Guidelines 2.1 (WCAG 2.1). These guidelines explain how to make web content more accessible for people with disabilities and more user-friendly for everyone.
          </p>
          <p>
            The guidelines have three levels of accessibility (A, AA, and AAA). We've chosen Level AA as our target.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Measures We Take to Support Accessibility</h2>
          <p>
            We take the following measures to ensure accessibility of our website:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Include accessibility as part of our mission statement</li>
            <li>Integrate accessibility into our procurement practices</li>
            <li>Appoint an accessibility officer and/or team for the website</li>
            <li>Provide continual accessibility training for our staff</li>
            <li>Include people with disabilities in our user experience research</li>
            <li>Employ formal accessibility quality assurance methods</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Specific Features and Accommodations</h2>
          <p>
            Our website includes the following features to improve accessibility:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Semantic HTML markup with appropriate headings and landmarks</li>
            <li>Sufficient color contrast between text and background</li>
            <li>Text alternatives for non-text content</li>
            <li>Keyboard accessibility for all interactive elements</li>
            <li>Clear focus indicators for keyboard navigation</li>
            <li>Resizable text without loss of content or functionality</li>
            <li>Alternative methods for content that relies on sensory characteristics</li>
            <li>Form labels and error messages that are clearly associated with form controls</li>
            <li>ARIA attributes where appropriate to enhance accessibility</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Compatibility with Browsers and Assistive Technology</h2>
          <p>
            We aim to support the following browsers and assistive technologies:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Latest versions of major browsers (Chrome, Firefox, Safari, Edge)</li>
            <li>Screen readers (NVDA, JAWS, VoiceOver, TalkBack)</li>
            <li>Zoom and magnification tools</li>
            <li>Speech recognition software</li>
            <li>Keyboard-only navigation</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Known Limitations</h2>
          <p>
            Despite our best efforts to ensure accessibility of our website, there may be some limitations. Below is a description of known limitations, and potential solutions. Please contact us if you observe an issue not listed below.
          </p>
          <p>
            Known limitations:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Some older content may not be fully accessible. We are working to update these pages.</li>
            <li>Some third-party content may not be fully accessible. We are working with our partners to improve this.</li>
            <li>Some interactive features may have limited accessibility on mobile devices. We are developing mobile-specific alternatives.</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Feedback and Contact Information</h2>
          <p>
            We welcome your feedback on the accessibility of our website. Please let us know if you encounter accessibility barriers:
          </p>
          <p className="mt-2">
            Email: accessibility@tashluxe.com<br />
            Phone: +44 20 1234 5678<br />
            Address: 123 Fashion Street, London, UK, W1 1AA
          </p>
          <p>
            We try to respond to feedback within 3 business days.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Assessment and Compliance Status</h2>
          <p>
            The Web Content Accessibility Guidelines (WCAG) defines requirements for designers and developers to improve accessibility for people with disabilities. It defines three levels of conformance: Level A, Level AA, and Level AAA.
          </p>
          <p>
            TꓥSHLUXE's website is partially conformant with WCAG 2.1 level AA. Partially conformant means that some parts of the content do not fully conform to the accessibility standard.
          </p>
          <p>
            We assessed the accessibility of our website using the following approaches:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Self-evaluation</li>
            <li>External evaluation by accessibility experts</li>
            <li>User testing with people who use assistive technologies</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Continuous Improvement</h2>
          <p>
            We are committed to continually improving the accessibility of our website. We will:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Conduct regular accessibility audits</li>
            <li>Address accessibility issues as they are identified</li>
            <li>Provide regular training for our staff on digital accessibility</li>
            <li>Engage with users with disabilities to get feedback on our website</li>
            <li>Stay informed about new technologies and standards related to accessibility</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Additional Resources</h2>
          <p>
            For more information about web accessibility, please visit these resources:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li><a href="https://www.w3.org/WAI/standards-guidelines/wcag/" className="text-accent hover:underline">Web Content Accessibility Guidelines (WCAG)</a></li>
            <li><a href="https://www.w3.org/WAI/" className="text-accent hover:underline">W3C Web Accessibility Initiative (WAI)</a></li>
            <li><a href="https://www.gov.uk/service-manual/helping-people-to-use-your-service/understanding-wcag" className="text-accent hover:underline">UK Government's Understanding WCAG 2.1</a></li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Accessibility;
