import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

const TermsConditions = () => {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-3xl mx-auto">
        <Link to="/" className="inline-flex items-center text-primary-700 hover:text-accent mb-8">
          <ArrowLeft size={16} className="mr-2" />
          Back to Home
        </Link>
        
        <h1 className="text-3xl font-bold mb-6">Terms & Conditions</h1>
        <p className="text-primary-600 mb-8">Last Updated: June 1, 2023</p>
        
        <div className="prose max-w-none">
          <p>
            Welcome to TꓥSHLUXE. These Terms and Conditions govern your use of our website and the purchase of products from our online store. By accessing our website or placing an order, you agree to be bound by these Terms and Conditions.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">1. Acceptance of Terms</h2>
          <p>
            By accessing or using our website, you agree to be bound by these Terms and Conditions and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this site.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">2. Changes to Terms</h2>
          <p>
            We reserve the right to modify these Terms and Conditions at any time. Changes will be effective immediately upon posting on our website. Your continued use of the website following the posting of changes constitutes your acceptance of those changes.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">3. Online Store Terms</h2>
          <p>
            By agreeing to these Terms and Conditions, you represent that you are at least the age of majority in your country, state, or province of residence, and you have given us your consent to allow any of your minor dependents to use this site.
          </p>
          <p>
            You may not use our products for any illegal or unauthorized purpose, nor may you, in the use of the Service, violate any laws in your jurisdiction (including but not limited to copyright laws).
          </p>
          <p>
            A breach or violation of any of the Terms will result in an immediate termination of your Services.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">4. Products and Services</h2>
          <p>
            All products are subject to availability. We reserve the right to discontinue any product at any time. Prices for our products are subject to change without notice.
          </p>
          <p>
            We reserve the right to limit the quantities of any products or services that we offer. All descriptions of products and pricing are subject to change at any time without notice, at our sole discretion.
          </p>
          <p>
            We reserve the right to refuse any order you place with us. We may, in our sole discretion, limit or cancel quantities purchased per person, per household, or per order.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">5. Order Acceptance and Pricing</h2>
          <p>
            We reserve the right to refuse or cancel your order if fraud or an unauthorized or illegal transaction is suspected. In the event that a product is mispriced, we reserve the right to refuse or cancel any orders placed for the mispriced product, regardless of whether the order has been confirmed and your payment card charged.
          </p>
          <p>
            All prices are shown in British Pounds (£) and include VAT where applicable. Shipping costs are not included in the price and will be added at checkout.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">6. Payment</h2>
          <p>
            We accept various payment methods, including credit/debit cards, PayPal, and other payment options as indicated at checkout. By providing a payment method, you represent and warrant that you are authorized to use the designated payment method and that the payment information you provide is true and accurate.
          </p>
          <p>
            We reserve the right to verify the identity of the credit card holder by requesting appropriate documentation.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">7. Shipping and Delivery</h2>
          <p>
            Delivery times are estimates only and commence from the date of shipping, not the date of order. We are not responsible for delivery delays beyond our control, including but not limited to delays caused by shipping carriers, weather conditions, or customs processing for international orders.
          </p>
          <p>
            Risk of loss and title for items purchased from our website pass to you upon delivery of the items to the carrier.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">8. Returns and Refunds</h2>
          <p>
            Our returns and refunds policy forms part of these Terms and Conditions. Please refer to our Returns & Exchanges page for detailed information.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">9. Account Registration</h2>
          <p>
            To access certain features of our website, you may be required to register for an account. You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete.
          </p>
          <p>
            You are responsible for safeguarding your password and for all activities that occur under your account. You agree to notify us immediately of any unauthorized use of your account.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">10. Intellectual Property</h2>
          <p>
            All content included on this website, such as text, graphics, logos, images, audio clips, digital downloads, data compilations, and software, is the property of TꓥSHLUXE or its content suppliers and protected by international copyright laws.
          </p>
          <p>
            Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of TꓥSHLUXE.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">11. User Content</h2>
          <p>
            If you submit any content to our website (such as reviews, comments, or images), you grant us a non-exclusive, royalty-free, perpetual, irrevocable, and fully sublicensable right to use, reproduce, modify, adapt, publish, translate, create derivative works from, distribute, and display such content throughout the world in any media.
          </p>
          <p>
            You represent and warrant that you own or control all rights to the content you submit, that the content is accurate, and that use of the content does not violate these Terms and Conditions and will not cause injury to any person or entity.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">12. Prohibited Uses</h2>
          <p>
            You may use our website only for lawful purposes and in accordance with these Terms and Conditions. You agree not to use our website:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>In any way that violates any applicable law or regulation</li>
            <li>To transmit any material that is defamatory, obscene, or offensive</li>
            <li>To impersonate or attempt to impersonate TꓥSHLUXE, a TꓥSHLUXE employee, another user, or any other person or entity</li>
            <li>To engage in any conduct that restricts or inhibits anyone's use or enjoyment of the website</li>
            <li>To attempt to gain unauthorized access to, interfere with, damage, or disrupt any parts of the website</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">13. Disclaimer of Warranties</h2>
          <p>
            Our website and all products and services delivered to you through the website are (except as expressly stated by us) provided 'as is' and 'as available' without any representation, warranties, or conditions of any kind.
          </p>
          <p>
            We do not guarantee, represent, or warrant that your use of our website will be uninterrupted, timely, secure, or error-free, or that the results that may be obtained from the use of the website will be accurate or reliable.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">14. Limitation of Liability</h2>
          <p>
            In no case shall TꓥSHLUXE, our directors, officers, employees, affiliates, agents, contractors, interns, suppliers, service providers, or licensors be liable for any injury, loss, claim, or any direct, indirect, incidental, punitive, special, or consequential damages of any kind, including, without limitation, lost profits, lost revenue, lost savings, loss of data, replacement costs, or any similar damages, whether based in contract, tort (including negligence), strict liability, or otherwise, arising from your use of any of the services or any products procured using the service, or for any other claim related in any way to your use of the service or any product.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">15. Indemnification</h2>
          <p>
            You agree to indemnify, defend, and hold harmless TꓥSHLUXE and our parent, subsidiaries, affiliates, partners, officers, directors, agents, contractors, licensors, service providers, subcontractors, suppliers, interns, and employees, from any claim or demand, including reasonable attorneys' fees, made by any third party due to or arising out of your breach of these Terms and Conditions or the documents they incorporate by reference, or your violation of any law or the rights of a third party.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">16. Severability</h2>
          <p>
            If any provision of these Terms and Conditions is determined to be unlawful, void, or unenforceable, such provision shall nonetheless be enforceable to the fullest extent permitted by applicable law, and the unenforceable portion shall be deemed to be severed from these Terms and Conditions. Such determination shall not affect the validity and enforceability of any other remaining provisions.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">17. Termination</h2>
          <p>
            These Terms and Conditions are effective unless and until terminated by either you or us. You may terminate these Terms and Conditions at any time by notifying us that you no longer wish to use our Services, or when you cease using our site.
          </p>
          <p>
            We may also terminate these Terms and Conditions at any time without notice, and accordingly may deny you access to our Services, if in our sole judgment you fail to comply with any term or provision of these Terms and Conditions.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">18. Governing Law</h2>
          <p>
            These Terms and Conditions and any separate agreements whereby we provide you Services shall be governed by and construed in accordance with the laws of the United Kingdom.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">19. Contact Information</h2>
          <p>
            Questions about the Terms and Conditions should be sent to us at:
          </p>
          <p className="mt-2">
            Email: legal@tashluxe.com<br />
            Phone: +44 20 1234 5678<br />
            Address: 123 Fashion Street, London, UK, W1 1AA
          </p>
        </div>
      </div>
    </div>
  );
};

export default TermsConditions;
