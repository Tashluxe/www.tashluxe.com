import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

const PrivacyPolicy = () => {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-3xl mx-auto">
        <Link to="/" className="inline-flex items-center text-primary-700 hover:text-accent mb-8">
          <ArrowLeft size={16} className="mr-2" />
          Back to Home
        </Link>
        
        <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
        <p className="text-primary-600 mb-8">Last Updated: June 1, 2023</p>
        
        <div className="prose max-w-none">
          <p>
            At TꓥSHLUXE, we are committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or make a purchase.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Information We Collect</h2>
          
          <h3 className="font-medium mt-6 mb-2">Personal Information</h3>
          <p>
            We may collect personal information that you voluntarily provide to us when you:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Register an account</li>
            <li>Place an order</li>
            <li>Sign up for our newsletter</li>
            <li>Contact our customer service</li>
            <li>Participate in promotions or surveys</li>
          </ul>
          <p>
            This information may include your name, email address, postal address, phone number, payment information, and any other information you choose to provide.
          </p>
          
          <h3 className="font-medium mt-6 mb-2">Automatically Collected Information</h3>
          <p>
            When you visit our website, we may automatically collect certain information about your device, including:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>IP address</li>
            <li>Browser type</li>
            <li>Operating system</li>
            <li>Referring website</li>
            <li>Pages viewed</li>
            <li>Time spent on pages</li>
            <li>Links clicked</li>
            <li>Search terms used</li>
          </ul>
          <p>
            We may also collect information about your online activities over time and across different websites when you use our website (behavioral tracking).
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">How We Use Your Information</h2>
          <p>
            We may use the information we collect for various purposes, including:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Processing and fulfilling your orders</li>
            <li>Managing your account</li>
            <li>Sending you order confirmations and updates</li>
            <li>Responding to your inquiries and providing customer support</li>
            <li>Sending you marketing communications (if you've opted in)</li>
            <li>Improving our website, products, and services</li>
            <li>Personalizing your shopping experience</li>
            <li>Preventing fraud and unauthorized access</li>
            <li>Complying with legal obligations</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Sharing Your Information</h2>
          <p>
            We may share your information with:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Service providers who help us operate our business (payment processors, shipping companies, etc.)</li>
            <li>Marketing partners (with your consent)</li>
            <li>Legal authorities when required by law</li>
            <li>Business partners in the event of a merger, acquisition, or sale of assets</li>
          </ul>
          <p>
            We do not sell your personal information to third parties.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Cookies and Tracking Technologies</h2>
          <p>
            We use cookies and similar tracking technologies to collect information about your browsing activities. Cookies are small data files stored on your device that help us improve our website and your experience, track usage patterns, and deliver targeted advertisements.
          </p>
          <p>
            You can set your browser to refuse all or some browser cookies, or to alert you when cookies are being sent. However, if you disable or refuse cookies, some parts of our website may not function properly.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Your Rights and Choices</h2>
          <p>
            Depending on your location, you may have certain rights regarding your personal information, including:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Accessing your personal information</li>
            <li>Correcting inaccurate information</li>
            <li>Deleting your personal information</li>
            <li>Restricting or objecting to processing</li>
            <li>Data portability</li>
            <li>Withdrawing consent</li>
          </ul>
          <p>
            To exercise these rights, please contact us using the information provided in the "Contact Us" section below.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Data Security</h2>
          <p>
            We implement appropriate technical and organizational measures to protect your personal information from unauthorized access, disclosure, alteration, and destruction. However, no method of transmission over the Internet or electronic storage is 100% secure, so we cannot guarantee absolute security.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Data Retention</h2>
          <p>
            We will retain your personal information for as long as necessary to fulfill the purposes outlined in this Privacy Policy, unless a longer retention period is required or permitted by law.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Children's Privacy</h2>
          <p>
            Our website is not intended for children under 16 years of age. We do not knowingly collect personal information from children under 16. If you are a parent or guardian and believe your child has provided us with personal information, please contact us, and we will delete such information from our records.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">International Transfers</h2>
          <p>
            Your information may be transferred to and processed in countries other than the one in which you reside. These countries may have different data protection laws than your country of residence. We will take appropriate measures to ensure that your personal information remains protected in accordance with this Privacy Policy.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Changes to This Privacy Policy</h2>
          <p>
            We may update this Privacy Policy from time to time to reflect changes in our practices or for other operational, legal, or regulatory reasons. We will notify you of any material changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.
          </p>
          
          <h2 className="text-xl font-semibold mt-8 mb-4">Contact Us</h2>
          <p>
            If you have any questions or concerns about this Privacy Policy or our privacy practices, please contact us at:
          </p>
          <p className="mt-2">
            Email: privacy@tashluxe.com<br />
            Phone: +44 20 1234 5678<br />
            Address: 123 Fashion Street, London, UK, W1 1AA
          </p>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
