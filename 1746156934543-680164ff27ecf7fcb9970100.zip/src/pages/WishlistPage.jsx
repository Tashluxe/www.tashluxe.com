import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import Button from '../components/ui/Button';
import { Trash2, ShoppingBag, ArrowLeft, Heart } from 'lucide-react';

const WishlistPage = () => {
  const { wishlist, removeFromWishlist, clearWishlist } = useWishlist();
  const { addToCart } = useCart();
  const [imageErrors, setImageErrors] = useState({});
  const [selectedSizes, setSelectedSizes] = useState({});
  const [addedToCart, setAddedToCart] = useState({});

  // Fallback image if the original image fails to load
  const fallbackImage = "https://images.unsplash.com/photo-1561526116-e2460f4d40a9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=387&q=80";
  
  const handleImageError = (itemId) => {
    setImageErrors(prev => ({
      ...prev,
      [itemId]: true
    }));
  };

  const handleSizeChange = (productId, size) => {
    setSelectedSizes(prev => ({
      ...prev,
      [productId]: size
    }));
  };

  const handleAddToCart = (product) => {
    const selectedSize = selectedSizes[product.id];
    if (!selectedSize) return;
    
    addToCart(product, selectedSize, 1);
    
    // Show added to cart message
    setAddedToCart(prev => ({
      ...prev,
      [product.id]: true
    }));
    
    // Hide message after 2 seconds
    setTimeout(() => {
      setAddedToCart(prev => ({
        ...prev,
        [product.id]: false
      }));
    }, 2000);
  };

  if (wishlist.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-md mx-auto">
          <div className="flex justify-center mb-6">
            <Heart size={48} className="text-primary-300" />
          </div>
          <h1 className="text-3xl font-bold mb-4">Your Wishlist is Empty</h1>
          <p className="text-primary-600 mb-8">Save your favorite items to your wishlist to purchase them later.</p>
          <Link to="/">
            <Button variant="primary">Continue Shopping</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="flex justify-between items-center mb-10">
        <h1 className="text-3xl font-bold">Your Wishlist</h1>
        <button 
          onClick={clearWishlist}
          className="text-primary-600 hover:text-accent text-sm underline"
        >
          Clear All
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {wishlist.map((item) => (
          <div key={item.id} className="border border-primary-200 rounded-lg overflow-hidden bg-white">
            <div className="relative">
              <Link to={`/product/${item.id}`}>
                <img 
                  src={imageErrors[item.id] ? fallbackImage : item.image} 
                  alt={item.name} 
                  className="w-full h-[300px] object-cover object-center"
                  onError={() => handleImageError(item.id)}
                />
              </Link>
              <button 
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-md text-primary-500 hover:text-accent transition-colors"
                onClick={() => removeFromWishlist(item.id)}
                aria-label="Remove from wishlist"
              >
                <Trash2 size={16} />
              </button>
            </div>
            
            <div className="p-4">
              <Link to={`/product/${item.id}`}>
                <h3 className="font-medium mb-2">{item.name}</h3>
                <p className="text-accent font-semibold mb-4">£{item.price.toFixed(2)}</p>
              </Link>
              
              <div className="mb-4">
                <label className="text-sm font-medium mb-2 block">Select Size</label>
                <div className="flex flex-wrap gap-2">
                  {['XS', 'S', 'M', 'L', 'XL'].map(size => (
                    <button
                      key={size}
                      className={`w-10 h-10 flex items-center justify-center border ${
                        selectedSizes[item.id] === size 
                          ? 'border-accent bg-accent text-white' 
                          : 'border-primary-300 hover:border-accent'
                      } rounded-lg transition-colors text-sm`}
                      onClick={() => handleSizeChange(item.id, size)}
                    >
                      {size}
                    </button>
                  ))}
                </div>
                {!selectedSizes[item.id] && <p className="text-xs text-accent mt-2">Please select a size</p>}
              </div>
              
              <div className="relative">
                <Button 
                  variant="primary" 
                  className="w-full flex items-center justify-center text-sm py-2"
                  disabled={!selectedSizes[item.id]}
                  onClick={() => handleAddToCart(item)}
                >
                  <ShoppingBag size={16} className="mr-2" />
                  Add to Cart
                </Button>
                
                {addedToCart[item.id] && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-primary-900 text-white py-2 px-3 rounded text-xs text-center">
                    Added to cart successfully
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-10">
        <Link to="/" className="text-primary-700 hover:text-accent flex items-center">
          <ArrowLeft size={16} className="mr-2" /> Continue Shopping
        </Link>
      </div>
    </div>
  );
};

export default WishlistPage;
